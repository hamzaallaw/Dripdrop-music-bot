"""URL validation and platform detection.

Users can paste any link. Lavalink will fetch it, so we refuse anything that points at
the local machine or a private network (SSRF protection) before it reaches Lavalink.
"""

from __future__ import annotations

import asyncio
import ipaddress
import re
import socket
from dataclasses import dataclass
from enum import Enum
from urllib.parse import urlparse

MAX_URL_LENGTH = 2000
AUDIO_EXTENSIONS = {
    ".mp3", ".ogg", ".oga", ".opus", ".flac", ".wav", ".m4a", ".aac", ".webm", ".mka", ".mp4",
}
PLAYLIST_EXTENSIONS = {".m3u", ".m3u8", ".pls"}
_BLOCKED_SUFFIXES = (".local", ".internal", ".localdomain", ".lan", ".home", ".corp")


class Platform(Enum):
    """value = (display name, Lavalink source manager that must be enabled to play it)."""

    YOUTUBE = ("YouTube", "youtube")
    YOUTUBE_MUSIC = ("YouTube Music", "youtube")
    SPOTIFY = ("Spotify", "spotify")
    SOUNDCLOUD = ("SoundCloud", "soundcloud")
    APPLE_MUSIC = ("Apple Music", "applemusic")
    DEEZER = ("Deezer", "deezer")
    BANDCAMP = ("Bandcamp", "bandcamp")
    TWITCH = ("Twitch", "twitch")
    VIMEO = ("Vimeo", "vimeo")
    HTTP = ("Direct audio / radio", "http")

    @property
    def label(self) -> str:
        return self.value[0]

    @property
    def source_manager(self) -> str:
        return self.value[1]


_DOMAINS: tuple[tuple[Platform, tuple[str, ...]], ...] = (
    # Order matters: music.youtube.com must be checked before youtube.com.
    (Platform.YOUTUBE_MUSIC, ("music.youtube.com",)),
    (Platform.YOUTUBE, ("youtube.com", "youtu.be", "youtube-nocookie.com")),
    (Platform.SPOTIFY, ("open.spotify.com", "spotify.link")),
    (Platform.SOUNDCLOUD, ("soundcloud.com", "snd.sc")),
    (Platform.APPLE_MUSIC, ("music.apple.com",)),
    (Platform.DEEZER, ("deezer.com", "deezer.page.link", "dzr.page.link")),
    (Platform.BANDCAMP, ("bandcamp.com",)),
    (Platform.TWITCH, ("twitch.tv",)),
    (Platform.VIMEO, ("vimeo.com",)),
)


@dataclass(frozen=True)
class UrlCheck:
    ok: bool
    reason: str = ""


_SCHEME_RE = re.compile(r"^[a-z][a-z0-9+.\-]*://", re.IGNORECASE)


def is_url(text: str) -> bool:
    return text.strip().lower().startswith(("http://", "https://"))


def has_other_scheme(text: str) -> bool:
    """True for things like ftp://, file:// or data:// that we must reject, not search for."""
    text = text.strip()
    return bool(_SCHEME_RE.match(text)) and not is_url(text)


def detect_platform(url: str) -> Platform:
    """Return the platform for a URL. Unknown hosts are treated as direct/radio HTTP."""
    host = (urlparse(url.strip()).hostname or "").lower()
    for platform, domains in _DOMAINS:
        for domain in domains:
            if host == domain or host.endswith("." + domain):
                return platform
    return Platform.HTTP


def _ip_is_public(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    return ip.is_global and not ip.is_multicast


def validate_url(text: str) -> UrlCheck:
    """Cheap, offline checks. Call `ensure_public_host` too for unknown hosts."""
    text = text.strip()
    if not text:
        return UrlCheck(False, "That link is empty.")
    if len(text) > MAX_URL_LENGTH:
        return UrlCheck(False, "That link is too long.")
    if any(ch.isspace() or ord(ch) < 32 for ch in text):
        return UrlCheck(False, "That link contains invalid characters.")
    try:
        parsed = urlparse(text)
        host = parsed.hostname
        _ = parsed.port  # raises ValueError on a bad port
    except ValueError:
        return UrlCheck(False, "That doesn't look like a valid link.")
    if parsed.scheme not in {"http", "https"}:
        return UrlCheck(False, "Only http and https links are supported.")
    if not host:
        return UrlCheck(False, "That link has no host name.")
    if parsed.username or parsed.password:
        return UrlCheck(False, "Links with a username or password are not allowed.")

    host = host.lower().rstrip(".")
    if host == "localhost" or host.endswith(_BLOCKED_SUFFIXES):
        return UrlCheck(False, "Links to local or private addresses are not allowed.")
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return UrlCheck(True)  # a normal host name
    if not _ip_is_public(ip):
        return UrlCheck(False, "Links to local or private addresses are not allowed.")
    return UrlCheck(True)


async def ensure_public_host(url: str) -> UrlCheck:
    """Resolve the host name and make sure it only points at public addresses.

    Limitation: this cannot stop a DNS-rebinding attack that changes the answer after this
    check. It blocks the common cases (a name that points at 127.0.0.1 or 192.168.x.x).
    """
    host = (urlparse(url.strip()).hostname or "").lower()
    if not host:
        return UrlCheck(False, "That link has no host name.")
    try:
        ipaddress.ip_address(host)
        return validate_url(url)  # literal IP, already checked
    except ValueError:
        pass
    loop = asyncio.get_running_loop()
    try:
        infos = await asyncio.wait_for(loop.getaddrinfo(host, None, type=socket.SOCK_STREAM), timeout=5)
    except (socket.gaierror, asyncio.TimeoutError, OSError):
        return UrlCheck(False, "I couldn't find that website.")
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            return UrlCheck(False, "That link resolves to an invalid address.")
        if not _ip_is_public(ip):
            return UrlCheck(False, "Links to local or private addresses are not allowed.")
    return UrlCheck(True)


# Search prefixes understood by Lavalink and its plugins.
SEARCH_PREFIXES: dict[str, tuple[str, str]] = {
    # key: (prefix, Lavalink source manager that must be enabled)
    "youtube": ("ytsearch", "youtube"),
    "youtube_music": ("ytmsearch", "youtube"),
    "soundcloud": ("scsearch", "soundcloud"),
    "spotify": ("spsearch", "spotify"),
    "apple_music": ("amsearch", "applemusic"),
}


def build_identifier(query: str, source: str = "youtube") -> str:
    """Turn user input into a Lavalink identifier. URLs pass through, text becomes a search."""
    query = query.strip()
    if is_url(query):
        return query
    prefix = SEARCH_PREFIXES.get(source, SEARCH_PREFIXES["youtube"])[0]
    return f"{prefix}:{query}"
