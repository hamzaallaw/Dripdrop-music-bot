"""Anti-spam protection: a sliding-window limiter, one window per key (user id)."""

from __future__ import annotations

import time
from collections import deque
from collections.abc import Callable


class SpamGuard:
    """Allow at most `rate` actions per `per` seconds for each key."""

    def __init__(self, rate: int = 5, per: float = 10.0, *, clock: Callable[[], float] = time.monotonic):
        if rate < 1 or per <= 0:
            raise ValueError("rate must be >= 1 and per must be > 0")
        self.rate = rate
        self.per = per
        self._clock = clock
        self._hits: dict[int, deque[float]] = {}

    def check(self, key: int) -> float:
        """Record an action. Returns 0.0 if allowed, else the seconds to wait."""
        now = self._clock()
        window = self._hits.setdefault(key, deque())
        while window and now - window[0] >= self.per:
            window.popleft()
        if len(window) >= self.rate:
            return max(self.per - (now - window[0]), 0.01)
        window.append(now)
        if len(self._hits) > 5000:
            self._prune(now)
        return 0.0

    def _prune(self, now: float) -> None:
        for key in [k for k, w in self._hits.items() if not w or now - w[-1] >= self.per]:
            del self._hits[key]
