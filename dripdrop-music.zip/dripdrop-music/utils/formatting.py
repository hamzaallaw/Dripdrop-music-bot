"""Small text helpers shared by embeds and commands."""

from __future__ import annotations

import re

import discord

from config import branding

_CLOCK_RE = re.compile(r"^\d{1,3}(?::\d{1,2}){0,2}$")
_UNITS_RE = re.compile(r"^(?:(?P<h>\d+)h)?(?:(?P<m>\d+)m)?(?:(?P<s>\d+)s)?$", re.IGNORECASE)


def format_duration(ms: int, *, is_stream: bool = False) -> str:
    """12345 -> '0:12', 3_725_000 -> '1:02:05'. Streams show LIVE."""
    if is_stream:
        return "LIVE"
    total = max(int(ms), 0) // 1000
    hours, rem = divmod(total, 3600)
    minutes, seconds = divmod(rem, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def progress_bar(position: int, duration: int, *, length: int = 14, is_stream: bool = False) -> str:
    """Text progress bar, for example '▬▬▬🔘▬▬▬▬▬▬▬▬▬▬'."""
    if is_stream or duration <= 0:
        return f"{branding.ICON_LIVE} LIVE"
    length = max(length, 4)
    ratio = min(max(position / duration, 0.0), 1.0)
    marker = min(int(ratio * length), length - 1)
    return "▬" * marker + "🔘" + "▬" * (length - marker - 1)


def truncate(text: str, limit: int) -> str:
    text = text.strip()
    if len(text) <= limit:
        return text
    return text[: max(limit - 1, 0)].rstrip() + "…"


def clean(text: str) -> str:
    """Escape markdown/mentions so a song title cannot format or ping anyone."""
    return discord.utils.escape_mentions(discord.utils.escape_markdown(text))


def parse_timestamp(text: str) -> int | None:
    """Parse '90', '1:30', '1:02:03' or '1m30s' into milliseconds. None if invalid."""
    text = text.strip().lower()
    if not text:
        return None
    if text.isdigit():
        return int(text) * 1000
    if _CLOCK_RE.match(text):
        parts = [int(p) for p in text.split(":")]
        if any(p >= 60 for p in parts[1:]):
            return None
        seconds = 0
        for part in parts:
            seconds = seconds * 60 + part
        return seconds * 1000
    match = _UNITS_RE.match(text)
    if match and any(match.group(g) for g in ("h", "m", "s")):
        h, m, s = (int(match.group(g) or 0) for g in ("h", "m", "s"))
        return (h * 3600 + m * 60 + s) * 1000
    return None
