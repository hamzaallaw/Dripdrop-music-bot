@echo off
rem DripDrop Music - start the bot. Restarts itself if it crashes. Close the window to stop it.
cd /d "%~dp0"
title DripDrop Music

if not exist ".venv\Scripts\python.exe" (
    echo Run install.bat first.
    pause
    exit /b 1
)
if not exist ".env" (
    echo Missing .env file. Run install.bat first.
    pause
    exit /b 1
)

:run
".venv\Scripts\python.exe" main.py
set CODE=%ERRORLEVEL%
rem Exit codes 2 and 3 are configuration problems: restarting will not fix them.
if %CODE% EQU 2 ( pause & exit /b 2 )
if %CODE% EQU 3 ( pause & exit /b 3 )
echo.
echo The bot stopped (code %CODE%). Restarting in 5 seconds... close this window to stop.
timeout /t 5 /nobreak >nul
goto run
