# DripDrop Music: honest status

Updated 2026-11-09. A feature is only called **Verified** if an automated test (or a real run) proved it.

## Verified here (160 automated tests, all passing)

| Area | What the tests prove |
|---|---|
| Settings | Missing/invalid token, password, port, volume and IDs are rejected with clear messages. Secrets never appear in logs. |
| URL safety | `localhost`, private IPs, cloud-metadata IPs, `file://`, `ftp://`, passwords in links and DNS names that point at private addresses are refused before Lavalink sees them. |
| Platform detection | All 11 platforms, including look-alike domains (`evilyoutube.com.attacker.net` is NOT treated as YouTube). |
| Honest capabilities | If Lavalink lacks Spotify/Apple Music/etc., the bot says so and never sends the request. |
| Queue logic | Add, remove, move, clear, shuffle, loop (track/queue), previous, skip-while-looping. |
| Persistence | SQLite settings, saved queues, user playlists (limits, SQL-injection attempt, per-user isolation). Damaged rows are skipped, not crashes. |
| Deezer | Link parsing and metadata handling with a fake Deezer API. Audio is matched on YouTube at play time. |
| Lyrics | Title cleanup, artist/title split, paging, LRCLIB lookup with a fake API. |
| Autoplay | Picks fresh tracks, avoids repeats, survives Lavalink failures. |
| Discord layer | All cogs load. Every slash command is a valid Discord definition. `/247` and `/settings` require Manage Server. Embeds and buttons build and stay within Discord's length limits. DJ-role rules. |
| Lavalink protocol | The real Lavalink.py client was run against a fake Lavalink v4 server: connects, reads `/v4/info`, loads search/track/playlist/error results, rejects a wrong password, detects a dropped connection and reconnects. |

## NOT verified yet (needs your PC: real Discord + real Lavalink + internet)

This workspace blocks the Lavalink plugin repository, YouTube and the music sites, so none of the following could be run here.

| Item | Why it matters |
|---|---|
| **Audio actually playing** on any platform | Only a real voice channel proves it. |
| Plugin versions in `lavalink/application.yml` (youtube-plugin 1.18.2, LavaSrc 4.8.3) | Taken from release pages. Never downloaded, so a wrong coordinate shows up in `docker compose logs lavalink`. |
| YouTube client names in the config | May need adjusting to the plugin's current list. |
| Docker image tag `ghcr.io/lavalink-devs/lavalink:4` | Believed correct, not pulled. |
| Joining voice with Discord's DAVE encryption | Depends on Lavalink 4.2+, discord.py 2.7+ and Lavalink.py 5.11+ all being current. The bot logs an error if Lavalink is too old. |
| Real button clicks, search menu, `/lyrics` paging | Built and size-checked, not clicked in Discord. |
| 24/7 mode reconnection, auto-leave, queue restore | Logic written, not exercised against real voice. |
| `install.bat`, `start.bat` | Written for Windows, not run on Windows. |

## Platform matrix

Run `scripts/test_sources.py` on your PC to fill this in for real (it writes `docs/SOURCE_TEST_RESULTS.md`).

| Platform | How it works | Keys needed | Verified |
|---|---|---|---|
| YouTube | youtube-source plugin | none (OAuth strongly advised) | Not yet |
| YouTube Music | youtube-source (`ytmsearch:`) | same | Not yet |
| Spotify | LavaSrc metadata, audio matched on YouTube | Spotify client ID + secret | Not yet |
| SoundCloud | Lavalink built-in | none | Not yet |
| Apple Music | LavaSrc metadata, audio matched on YouTube | Apple Music token | Not yet |
| Deezer | Deezer public API metadata, audio matched on YouTube. Deezer's own audio is deliberately not used. | none | Metadata logic tested with a fake API; real call not yet |
| Bandcamp | Lavalink built-in | none | Not yet |
| Twitch | Lavalink built-in, live streams only | none | Not yet |
| Vimeo | Lavalink built-in (historically fragile) | none | Not yet |
| Direct MP3 / audio URLs | Lavalink HTTP source | none | Not yet |
| Radio streams | Lavalink HTTP source (MP3/AAC/OGG, M3U/PLS) | none | Not yet |

## Known limits

- Slash commands only. `/prefix` was not built because the bot has no text prefix.
- Spotify, Apple Music and Deezer need a working YouTube (or SoundCloud) to produce sound. If YouTube is blocked, those fail too.
- A mirrored track can occasionally match the wrong song or version.
- Lyrics come from LRCLIB (community database), so coverage is not complete.
