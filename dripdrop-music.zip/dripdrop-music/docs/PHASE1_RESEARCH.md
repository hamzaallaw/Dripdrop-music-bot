# DripDrop Music - Phase 1 Research Report

Date: 2026-11-08
Status: RESEARCH ONLY. Nothing here has been installed or run yet. Every "works" claim below is a claim from documentation and must be confirmed in Phase 2.

---

## 1. Critical finding: DAVE (Discord voice encryption)

Discord enforced end-to-end encrypted voice (DAVE) for all voice calls from early March 2026.
Consequences for this project:

- Lavalink must be **4.2.0 or newer** (first release with DAVE). Latest version I could verify: **4.2.1** (Mar 2026). Re-check the releases page at install time.
- The Python client library must send `channelId` in voice state payloads. Older clients silently fail to connect.
- DAVE needs glibc 2.35+ (Ubuntu 22.04+). Use the default Ubuntu-based Lavalink Docker image. Do NOT use the alpine/musl image until DAVE on musl is verified.
- Lavalink needs Java 17+.

## 2. Verified component choices

| Component | Choice | Version seen | Notes |
|---|---|---|---|
| Lavalink server | lavalink-devs/Lavalink | 4.2.1 | Needs DAVE-aware client |
| YouTube | `dev.lavalink.youtube:youtube-plugin` (official) | 1.18.2 | Built-in YouTube source MUST be set to `false` |
| Spotify / Apple Music / Deezer | LavaSrc `com.github.topi314.lavasrc:lavasrc-plugin` | 4.8.3 | Repo: `https://maven.lavalink.dev/releases` |
| Search | LavaSearch plugin | check at install | Powers `/search` with albums/artists/playlists |
| Lyrics | LavaLyrics + a provider plugin | check at install | See section 4 |
| Python client | **Lavalink.py (devoxin)** | 5.11.0 | Confirmed DAVE support, maintained, works with discord.py |
| Bot framework | discord.py 2.x | check at install | |

### Why not Wavelink
- The official PythonistaGuild/Wavelink repo was **archived on Apr 5, 2025**. Last release 3.4.1.
- lavalink.dev's client table lists Wavelink as DAVE-compatible, but the original repo is archived, so I cannot confirm which build that refers to. A community fork (`wavelink-wyno`) claims DAVE support.
- Your brief allows "Wavelink or a compatible Lavalink client". Lavalink.py is the safer pick: it is the only Python client I verified with an explicit DAVE changelog entry (5.11.0 says the upgrade is mandatory for Lavalink 4.2.0).
- Trade-off: Lavalink.py is lower-level. Queue, autoplay and the voice client class will be written by us (more code, more control).

## 3. Source support matrix

Legend: DIRECT = Lavalink plays it itself. MIRROR = metadata only, audio is found on another provider. RISK = works in theory, known fragility.

| # | Platform | Mechanism | Type | Credentials | Phase 2 status |
|---|---|---|---|---|---|
| 1 | YouTube | youtube-source plugin | DIRECT | Optional OAuth / poToken | UNTESTED |
| 2 | YouTube Music | youtube-source (`ytmsearch:`) | DIRECT | same as above | UNTESTED |
| 3 | Spotify | LavaSrc | MIRROR | Spotify clientId + clientSecret | UNTESTED |
| 4 | SoundCloud | Lavaplayer built-in | DIRECT | none | UNTESTED |
| 5 | Apple Music | LavaSrc | MIRROR | Apple Music API token (or Apple developer key) | UNTESTED |
| 6 | Deezer | LavaSrc | see note | Deezer arl + master decryption key for native play | UNTESTED, RISK |
| 7 | Bandcamp | Lavaplayer built-in | DIRECT | none | UNTESTED |
| 8 | Twitch streams | Lavaplayer built-in | DIRECT (live only) | none | UNTESTED |
| 9 | Vimeo | Lavaplayer built-in | DIRECT | none | UNTESTED, RISK |
| 10 | Direct MP3/audio URLs | Lavaplayer HTTP source | DIRECT | none | UNTESTED |
| 11 | Radio streams | Lavaplayer HTTP source (MP3/AAC/OGG, M3U/PLS) | DIRECT | none | UNTESTED |

Supported container formats (Lavaplayer): MP3, FLAC, WAV, Matroska/WebM, MP4/M4A (AAC), OGG (Opus/Vorbis/FLAC), AAC streams, M3U/PLS playlists.

### Platform notes (honest limitations)
- **Spotify / Apple Music** never play from their own servers. LavaSrc reads the metadata and finds a match on a playable provider (YouTube by default). If the match is wrong or the provider is blocked, playback fails. The bot UI will label these as "resolved via <provider>".
- **Deezer**: LavaSrc's native Deezer playback needs a `masterDecryptionKey` that Deezer does not publish. Relying on it conflicts with your "respect content licensing" requirement. Plan: do NOT enable native Deezer decryption. Deezer links/search go through metadata + mirroring. Whether mirroring works without the key must be verified in Phase 2.
- **Apple Music token**: the no-account method scrapes a token from the Apple Music website, which can expire. A proper Apple developer key is the stable option.
- **YouTube**: YouTube actively blocks server and datacenter IPs. Expect "sign in to confirm you're not a bot" errors. Mitigations: OAuth with a throwaway Google account, poToken, or running from a home IP. Home Windows machine is the best case.
- **Vimeo**: built into Lavaplayer but historically fragile. Will test with a public video before claiming support.
- **Twitch**: live streams only (no VODs claimed).
- **SoundCloud**: Lavalink 4.2.0 added a config option to filter preview-only tracks.

## 4. Lyrics, search, autoplay

- Lyrics options found: LavaLyrics (API base), Lyrics.kt (timestamped, from YouTube), Java Timed Lyrics (YouTube with Genius fallback), plus LavaSrc's own lyric sources (Spotify, Deezer, YouTube). Plan: LavaLyrics + a provider, tested in Phase 2. Fallback if plugins fail: an HTTP lyrics API called via aiohttp (provider not yet chosen or verified).
- `/search` will use LavaSearch if it loads; otherwise plain `ytsearch:` / `scsearch:` results.
- Autoplay: Lavalink.py has no built-in autoplay. Candidates: LavaSrc recommendations (Deezer/Spotify seed) or a YouTube Mix playlist. Needs Phase 2 testing.

## 5. Credentials checklist (what the user will need)

| Item | Needed for | Required? |
|---|---|---|
| Discord bot token + application ID | Everything | Yes |
| Lavalink password (we generate) | Bot to Lavalink auth | Yes |
| Spotify clientId / clientSecret | Spotify links | For Spotify |
| Apple Music API token or developer key | Apple Music links | For Apple Music |
| Deezer arl | Only if Deezer features need it | Optional, see note |
| Throwaway Google account (OAuth) | Reliable YouTube | Strongly recommended |

## 6. Risks to track

1. DAVE requirements break older libs. Mitigation: pin Lavalink >= 4.2.0 and Lavalink.py >= 5.11.0.
2. YouTube blocking. Mitigation above.
3. Plugin versions drift quickly. Mitigation: pin exact versions in `application.yml`, re-verify at build time.
4. Mirror sources can pick the wrong track.
5. Sandbox limitation: the environment I work in restricts outbound network access. I may not be able to download Lavalink/plugins or reach music services here, so Phase 2 audio tests may have to be run on your Windows PC (Docker Desktop) with me reading the logs you paste back.

## 7. Phase 2 test plan

1. `docker compose up` Lavalink 4.2.x with youtube-plugin, LavaSrc, LavaSearch, LavaLyrics.
2. Check `/v4/info`: confirm plugin list and enabled sources.
3. Call `/v4/loadtracks` for one URL per platform in the matrix; record result, latency, errors.
4. Update the matrix "Phase 2 status" column to PASS / FAIL / PARTIAL with evidence.
5. Drop or relabel any source that fails. No source is marked supported without a passing test.
