# DripDrop Music: Windows setup guide

About 20 minutes. You need a Windows 10/11 PC that stays on while the bot is running.

## 1. Install the tools (once)

1. **Python 3.12 or newer**: https://www.python.org/downloads/ . In the installer, tick **Add python.exe to PATH**.
2. **Docker Desktop**: https://www.docker.com/products/docker-desktop/ . Accept the WSL 2 option, restart Windows if asked, and open Docker Desktop once so it is running (whale icon in the tray).

## 2. Create the Discord bot

1. Go to https://discord.com/developers/applications and click **New Application**. Name it **DripDrop Music**.
2. Open the **Bot** tab. Click **Reset Token**, copy the token and keep it secret. Anyone with it controls your bot.
3. You do **not** need to turn on any "Privileged Gateway Intents".
4. Copy your **Application ID** (General Information tab) and open this link, replacing `YOUR_APP_ID`:

   `https://discord.com/oauth2/authorize?client_id=YOUR_APP_ID&scope=bot%20applications.commands&permissions=3165184`

   Pick your server and authorize. (Permissions: View Channel, Send Messages, Embed Links, Connect, Speak.)

## 3. Set up the project

1. Put the `dripdrop-music` folder somewhere simple, like `C:\dripdrop-music`.
2. Double-click **install.bat**. It installs the Python parts and opens `.env` in Notepad.
3. In `.env` fill in:
   - `DISCORD_TOKEN`: the token from step 2.
   - `LAVALINK_PASSWORD`: make up a long random password (letters and numbers).
   - `DEV_GUILD_ID` (recommended while testing): your server's ID (Discord Settings > Advanced > Developer Mode on, then right-click your server > Copy Server ID). Commands then appear instantly instead of after up to an hour.
4. Save and close Notepad.

## 4. Start the music server (Lavalink)

Open **Command Prompt** in the project folder (type `cmd` in the folder's address bar) and run:

```
docker compose up -d
docker compose logs -f lavalink
```

The first start downloads Lavalink and its plugins, so wait until you see a line like `Lavalink is ready to accept connections`. Press `Ctrl+C` to stop watching the log (Lavalink keeps running).

**Check the version.** Near the top of the log, Lavalink prints its version. It must be **4.2.0 or newer**, because Discord now requires encrypted voice. If it is older: `docker compose pull` then `docker compose up -d`.

## 5. Test the platforms (recommended)

```
.venv\Scripts\python.exe scripts\test_sources.py
```

You get PASS / FAIL / SKIP for YouTube, YouTube Music, Spotify, SoundCloud, Apple Music, Bandcamp, Twitch, Vimeo, direct MP3 links, radio and Deezer. For Bandcamp and Twitch add your own links:

```
.venv\Scripts\python.exe scripts\test_sources.py --url bandcamp=https://ARTIST.bandcamp.com/track/SONG --url twitch=https://www.twitch.tv/SOME_LIVE_CHANNEL
```

PASS means Lavalink could read the track. Confirm real audio once with `/play` in Discord.

## 6. Start the bot

Double-click **start.bat**. You should see `DripDrop Music online as ...`. In Discord, join a voice channel and type `/play never gonna give you up`.

To run it every day: keep Docker Desktop open (it starts Lavalink automatically) and start `start.bat`. Closing the window stops the bot.

## Optional platform keys

| Platform | What to do |
|---|---|
| **YouTube (recommended)** | YouTube often blocks music bots with "Sign in to confirm you're not a bot". Fix: in `lavalink/application.yml`, remove the `#` signs in front of the `oauth:` block under `plugins: youtube:`, then `docker compose restart lavalink`. Run `docker compose logs lavalink`, open the `google.com/device` link it shows, and sign in with a **throwaway Google account, never your main one**. Running the bot from your home PC (not a rented server) also helps a lot. |
| **Spotify** | https://developer.spotify.com/dashboard > Create app. Put the Client ID and Secret in `.env`, set `SPOTIFY_ENABLED=true`, then `docker compose up -d`. Spotify gives only song info. The audio itself is found on YouTube. |
| **Apple Music** | Needs an Apple Music API token (Apple developer account, or the method in the [LavaSrc docs](https://github.com/topi314/LavaSrc#apple-music)). Put it in `APPLE_MUSIC_TOKEN`, set `APPLE_MUSIC_ENABLED=true`. Audio is found on YouTube. |
| **Deezer** | No key needed. The bot reads Deezer's public song info and finds the audio on YouTube. |
| SoundCloud, Bandcamp, Twitch, Vimeo, MP3 links, radio | Work without keys. Twitch plays **live** streams only. |

`/help` in Discord shows which platforms are actually enabled on your bot right now.

## Troubleshooting

| Problem | Fix |
|---|---|
| `Configuration problem: DISCORD_TOKEN is missing` | Fill in `.env` (step 3). |
| Commands don't appear | Set `DEV_GUILD_ID` for instant commands, or wait up to an hour. Make sure you used the invite link with `applications.commands`. |
| "The music server is offline" | Lavalink isn't running or the passwords differ. Run `docker compose ps`, then `docker compose logs lavalink`. `LAVALINK_PASSWORD` in `.env` is used by both sides. |
| Bot joins but there is no sound | Lavalink older than 4.2.0 (see step 4), or an outdated Python package: `.venv\Scripts\python.exe -m pip install -U -r requirements.txt`. |
| "YouTube is blocking the music server" | Enable OAuth (table above). |
| A plugin is missing in the Lavalink log | The plugin version numbers in `lavalink/application.yml` may be outdated. Check the releases of [youtube-source](https://github.com/lavalink-devs/youtube-source/releases) and [LavaSrc](https://github.com/topi314/LavaSrc/releases) and update the numbers. |
| Spotify/Apple links say "not enabled" | Keys missing or `*_ENABLED` is still `false`. |

## Updating

```
docker compose pull
docker compose up -d
.venv\Scripts\python.exe -m pip install -U -r requirements.txt
```

## Hosting 24/7

A Windows PC works as long as it stays on. For a server (Linux VPS), install Docker and Python 3.12, copy the folder, run `docker compose up -d`, and run `python main.py` under `systemd` or `pm2`. Note that YouTube blocks datacenter IPs more aggressively, so OAuth is almost required there.
