"""Check which music platforms your Lavalink server can really load.

Run this on the computer where Lavalink is running, AFTER `docker compose up -d`:

    python scripts/test_sources.py
    python scripts/test_sources.py --url bandcamp=https://artist.bandcamp.com/track/xyz --url twitch=https://www.twitch.tv/somelivechannel

It talks to Lavalink directly (no Discord needed), tries one query per platform, and prints PASS,
FAIL or SKIP. It also writes docs/SOURCE_TEST_RESULTS.md.

What a PASS means: Lavalink found and decoded the track's information.
What it does NOT prove: that audio plays all the way through in a voice channel. Confirm that
once in Discord with /play for each platform you care about.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import aiohttp

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402


@dataclass
class Case:
    key: str
    label: str
    identifier: str | None
    note: str = ""
    needs: str = ""  # Lavalink source manager that must be enabled


def default_cases() -> list[Case]:
    return [
        Case("youtube", "YouTube (search)", "ytsearch:never gonna give you up", needs="youtube"),
        Case("youtube_url", "YouTube (link)", "https://www.youtube.com/watch?v=dQw4w9WgXcQ", needs="youtube"),
        Case("youtube_music", "YouTube Music (search)", "ytmsearch:daft punk one more time", needs="youtube"),
        Case("spotify", "Spotify (search)", "spsearch:daft punk one more time", "needs Spotify keys + LavaSrc", "spotify"),
        Case("apple_music", "Apple Music (search)", "amsearch:daft punk one more time", "needs Apple Music token + LavaSrc", "applemusic"),
        Case("soundcloud", "SoundCloud (search)", "scsearch:lofi hip hop", needs="soundcloud"),
        Case("http", "Direct MP3 link", "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", needs="http"),
        Case("radio", "Radio stream", "https://ice1.somafm.com/groovesalad-128-mp3", "SomaFM Groove Salad", "http"),
        Case("vimeo", "Vimeo", "https://vimeo.com/76979871", "public sample video", "vimeo"),
        Case("bandcamp", "Bandcamp", None, "pass a track link with --url bandcamp=...", "bandcamp"),
        Case("twitch", "Twitch live stream", None, "pass a LIVE channel with --url twitch=...", "twitch"),
        Case("deezer", "Deezer (metadata via the bot)", None, "tested by the bot itself, see below", ""),
    ]


async def load(session: aiohttp.ClientSession, base: str, headers: dict, identifier: str) -> tuple[str, str]:
    start = time.monotonic()
    try:
        async with session.get(
            f"{base}/v4/loadtracks", params={"identifier": identifier}, headers=headers,
            timeout=aiohttp.ClientTimeout(total=45),
        ) as resp:
            if resp.status == 401:
                return "FAIL", "Lavalink rejected the password (check LAVALINK_PASSWORD)"
            data = await resp.json(content_type=None)
    except (aiohttp.ClientError, TimeoutError) as exc:
        return "FAIL", f"request failed: {exc}"
    took = f"{time.monotonic() - start:.1f}s"
    kind = data.get("loadType")
    payload = data.get("data")
    if kind == "error":
        return "FAIL", f"{payload.get('message')} ({payload.get('cause', '')[:120]})"
    if kind == "empty":
        return "FAIL", "nothing found"
    if kind == "track":
        info = payload["info"]
    elif kind in ("search",):
        info = payload[0]["info"]
    elif kind == "playlist":
        info = payload["tracks"][0]["info"]
    else:
        return "FAIL", f"unexpected answer: {kind}"
    live = " (live stream)" if info.get("isStream") else ""
    return "PASS", f"{info.get('title', '?')[:60]} by {info.get('author', '?')[:30]}{live} [{took}]"


async def test_deezer(session: aiohttp.ClientSession) -> tuple[str, str]:
    from services import deezer

    try:
        data = await deezer.fetch(session, "https://www.deezer.com/track/3135556")
    except Exception as exc:  # noqa: BLE001
        return "FAIL", f"Deezer lookup failed: {exc}"
    t = data.tracks[0]
    return "PASS", f"metadata OK: {t.artist} - {t.title}. Audio is found on YouTube when played (verify with /play in Discord)."


async def main() -> int:
    load_dotenv(ROOT / ".env")
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--host", default=os.getenv("LAVALINK_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("LAVALINK_PORT", "2333")))
    parser.add_argument("--password", default=os.getenv("LAVALINK_PASSWORD", ""))
    parser.add_argument("--url", action="append", default=[], metavar="KEY=LINK", help="override or add a test link")
    args = parser.parse_args()
    if not args.password:
        print("LAVALINK_PASSWORD is not set (put it in .env).")
        return 2

    overrides = dict(item.split("=", 1) for item in args.url if "=" in item)
    cases = default_cases()
    for case in cases:
        if case.key in overrides:
            case.identifier = overrides.pop(case.key)
    for key, link in overrides.items():
        cases.append(Case(key, key, link))

    base = f"http://{args.host}:{args.port}"
    headers = {"Authorization": args.password}
    rows: list[tuple[str, str, str]] = []

    async with aiohttp.ClientSession(headers={"User-Agent": "DripDropMusic-sourcetest/1.0"}) as session:
        try:
            async with session.get(f"{base}/v4/info", headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 401:
                    print("Lavalink is running but rejected the password.")
                    return 2
                info = await resp.json(content_type=None)
        except (aiohttp.ClientError, TimeoutError) as exc:
            print(f"Cannot reach Lavalink at {base}: {exc}\nIs it running?  docker compose up -d  /  docker compose logs lavalink")
            return 2

        version = info.get("version", {}).get("semver", "unknown")
        sources = sorted(info.get("sourceManagers", []))
        plugins = [f"{p['name']} {p['version']}" for p in info.get("plugins", [])]
        print(f"Lavalink {version}")
        print(f"Source managers: {', '.join(sources) or 'none'}")
        print(f"Plugins: {', '.join(plugins) or 'none'}\n")
        major_minor = tuple(int(x) for x in version.split("-")[0].split(".")[:2]) if version[0].isdigit() else (0, 0)
        if major_minor < (4, 2):
            print("WARNING: Lavalink is older than 4.2.0. Discord voice will not work. Update it.\n")

        for case in cases:
            if case.key == "deezer":
                status, detail = await test_deezer(session)
            elif case.identifier is None:
                status, detail = "SKIP", case.note
            elif case.needs and case.needs not in sources:
                status, detail = "FAIL", f"'{case.needs}' source is not enabled on Lavalink ({case.note or 'check application.yml / plugin logs'})"
            else:
                status, detail = await load(session, base, headers, case.identifier)
            rows.append((case.label, status, detail))
            print(f"[{status:<4}] {case.label:<32} {detail}")

    passed = sum(1 for _, s, _ in rows if s == "PASS")
    failed = sum(1 for _, s, _ in rows if s == "FAIL")
    print(f"\n{passed} passed, {failed} failed, {len(rows) - passed - failed} skipped")

    out = ROOT / "docs" / "SOURCE_TEST_RESULTS.md"
    out.parent.mkdir(exist_ok=True)
    lines = [
        "# Source test results", "",
        f"Run: {time.strftime('%Y-%m-%d %H:%M')} against Lavalink {version}", "",
        "PASS = Lavalink loaded the track information. It does not prove audio playback; confirm with /play in Discord.", "",
        "| Platform | Result | Detail |", "|---|---|---|",
        *[f"| {a} | {b} | {c.replace('|', '/')} |" for a, b, c in rows],
    ]
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved {out}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
