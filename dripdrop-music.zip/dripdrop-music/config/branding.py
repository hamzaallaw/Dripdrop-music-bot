"""DripDrop Music visual identity. Every embed in the bot uses these constants."""

from __future__ import annotations

NAME = "DripDrop Music"
TAGLINE = "Drop the beat."

# Dark, modern palette. NEUTRAL matches Discord's dark embed background.
COLOR_ACCENT = 0x8B5CF6   # violet, "now playing" and general brand colour
COLOR_NEUTRAL = 0x2B2D31  # blends with Discord dark theme
COLOR_SUCCESS = 0x3BA55D
COLOR_WARNING = 0xFAA61A
COLOR_ERROR = 0xED4245

# Plain unicode so it works on every server without custom emoji uploads.
ICON_PLAY = "▶️"
ICON_PAUSE = "⏸️"
ICON_SKIP = "⏭️"
ICON_PREVIOUS = "⏮️"
ICON_STOP = "⏹️"
ICON_LOOP = "🔁"
ICON_LOOP_ONE = "🔂"
ICON_QUEUE = "📜"
ICON_VOLUME = "🔊"
ICON_LIVE = "🔴"
ICON_OK = "✅"
ICON_WARN = "⚠️"
ICON_ERROR = "❌"
ICON_SEARCH = "🔎"
ICON_LYRICS = "🎤"
ICON_SHUFFLE = "🔀"
ICON_AUTOPLAY = "♾️"

FOOTER = f"{NAME} · {TAGLINE}"
