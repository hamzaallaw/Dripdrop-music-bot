"""Runtime settings loaded from environment variables (and an optional .env file).

Nothing secret is hardcoded. The Discord token only ever comes from the environment.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class ConfigError(RuntimeError):
    """Raised when required configuration is missing or invalid."""


def _int(env: dict[str, str], key: str, default: int, *, minimum: int, maximum: int) -> int:
    raw = env.get(key, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError(f"{key} must be a whole number, got {raw!r}") from None
    if not minimum <= value <= maximum:
        raise ConfigError(f"{key} must be between {minimum} and {maximum}, got {value}")
    return value


def _bool(env: dict[str, str], key: str, default: bool) -> bool:
    raw = env.get(key, "").strip().lower()
    if not raw:
        return default
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    raise ConfigError(f"{key} must be true or false, got {raw!r}")


def _id_set(env: dict[str, str], key: str) -> frozenset[int]:
    raw = env.get(key, "").strip()
    if not raw:
        return frozenset()
    try:
        return frozenset(int(part) for part in raw.replace(" ", "").split(",") if part)
    except ValueError:
        raise ConfigError(f"{key} must be a comma-separated list of numeric IDs") from None


@dataclass(frozen=True)
class Settings:
    discord_token: str
    lavalink_host: str
    lavalink_port: int
    lavalink_password: str
    lavalink_ssl: bool
    database_path: Path
    default_volume: int
    max_volume: int
    max_queue_size: int
    max_playlist_import: int
    owner_ids: frozenset[int]
    dev_guild_id: int | None
    log_level: str

    def __repr__(self) -> str:  # never leak secrets into logs
        return (
            f"Settings(lavalink={self.lavalink_host}:{self.lavalink_port}, "
            f"db={self.database_path}, token=<hidden>, password=<hidden>)"
        )


def load_settings(env_file: Path | None = None, environ: dict[str, str] | None = None) -> Settings:
    """Build Settings. `environ` exists so tests can pass a fake environment."""
    if environ is None:
        load_dotenv(env_file or PROJECT_ROOT / ".env")
        env = dict(os.environ)
    else:
        env = environ

    token = env.get("DISCORD_TOKEN", "").strip()
    if not token:
        raise ConfigError("DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.")
    if len(token) < 50 or " " in token:
        raise ConfigError(
            "DISCORD_TOKEN does not look like a bot token. Copy it from the Discord "
            "Developer Portal > your application > Bot > Reset Token."
        )

    password = env.get("LAVALINK_PASSWORD", "").strip()
    if not password:
        raise ConfigError("LAVALINK_PASSWORD is missing. It must match lavalink/application.yml.")

    db_raw = env.get("DATABASE_PATH", "data/dripdrop.db").strip() or "data/dripdrop.db"
    db_path = Path(db_raw)
    if not db_path.is_absolute():
        db_path = PROJECT_ROOT / db_path

    max_volume = _int(env, "MAX_VOLUME", 150, minimum=10, maximum=1000)
    default_volume = _int(env, "DEFAULT_VOLUME", 60, minimum=1, maximum=max_volume)
    dev_guild = _int(env, "DEV_GUILD_ID", 0, minimum=0, maximum=2**63 - 1)

    level = env.get("LOG_LEVEL", "INFO").strip().upper() or "INFO"
    if level not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
        raise ConfigError("LOG_LEVEL must be DEBUG, INFO, WARNING or ERROR")

    return Settings(
        discord_token=token,
        lavalink_host=env.get("LAVALINK_HOST", "127.0.0.1").strip() or "127.0.0.1",
        lavalink_port=_int(env, "LAVALINK_PORT", 2333, minimum=1, maximum=65535),
        lavalink_password=password,
        lavalink_ssl=_bool(env, "LAVALINK_SSL", False),
        database_path=db_path,
        default_volume=default_volume,
        max_volume=max_volume,
        max_queue_size=_int(env, "MAX_QUEUE_SIZE", 500, minimum=10, maximum=5000),
        max_playlist_import=_int(env, "MAX_PLAYLIST_IMPORT", 100, minimum=1, maximum=1000),
        owner_ids=_id_set(env, "OWNER_IDS"),
        dev_guild_id=dev_guild or None,
        log_level=level,
    )
