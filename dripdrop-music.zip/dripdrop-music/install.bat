@echo off
rem DripDrop Music - one-time setup for Windows. Double-click this file.
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.12 or newer from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add python.exe to PATH" in the installer, then run this file again.
    pause
    exit /b 1
)

py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)"
if errorlevel 1 (
    echo Your Python is too old. DripDrop Music needs Python 3.12 or newer.
    pause
    exit /b 1
)

if not exist ".venv" (
    echo Creating the Python environment...
    py -3 -m venv .venv
    if errorlevel 1 ( echo Could not create the environment. & pause & exit /b 1 )
)

echo Installing requirements (this can take a minute)...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 ( echo Install failed. Check your internet connection. & pause & exit /b 1 )

if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo.
    echo Created your settings file: .env
    echo Opening it now. Fill in DISCORD_TOKEN and LAVALINK_PASSWORD, save, then close it.
    start /wait notepad ".env"
)

echo.
echo Setup finished. Next: start Lavalink with   docker compose up -d   then run start.bat
pause
