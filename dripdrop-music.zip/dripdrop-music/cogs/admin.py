"""Administration: /247 and /settings. (There is no /prefix: the bot is slash-command only.)"""

from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from commands.checks import require_voice
from music import embeds
from music.errors import MusicError
from music.voice import get_player

if TYPE_CHECKING:
    from bot.client import DripDropBot


class Admin(commands.Cog):
    settings = app_commands.Group(
        name="settings",
        description="Change how DripDrop Music behaves in this server",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    def __init__(self, bot: DripDropBot):
        self.bot = bot

    @app_commands.command(name="247", description="Keep me in your voice channel all the time (or turn that off)")
    @app_commands.describe(enabled="Turn 24/7 mode on or off")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def always_on(self, interaction: discord.Interaction, enabled: bool) -> None:
        guild = interaction.guild
        assert guild is not None
        if not enabled:
            await self.bot.db.update_settings(guild.id, always_on=0, voice_channel_id=None)
            player = get_player(self.bot, guild.id)
            if player is not None:
                player.always_on = False
            await interaction.response.send_message(embed=embeds.success("24/7 mode is off. I'll leave when the room is empty."))
            return

        channel = require_voice(interaction)
        await interaction.response.defer()
        player = await self.bot.controller.ensure_player(interaction)
        player.always_on = True
        await self.bot.db.update_settings(
            guild.id, always_on=1, voice_channel_id=channel.id, text_channel_id=interaction.channel_id
        )
        await interaction.followup.send(
            embed=embeds.success(f"24/7 mode is on. I'll stay in {channel.mention} and rejoin if I get disconnected.")
        )

    @settings.command(name="show", description="Show the current settings")
    async def show(self, interaction: discord.Interaction) -> None:
        row = await self.bot.db.get_settings(interaction.guild_id, default_volume=self.bot.settings.default_volume)  # type: ignore[arg-type]
        await interaction.response.send_message(embed=embeds.settings_embed(row, interaction.guild), ephemeral=True)  # type: ignore[arg-type]

    @settings.command(name="dj-role", description="Only this role (plus Manage Server) can control the music")
    @app_commands.describe(role="The DJ role. Leave empty to let everyone control the music")
    async def dj_role(self, interaction: discord.Interaction, role: discord.Role | None = None) -> None:
        if role is not None and (role.is_default() or role.managed):
            raise MusicError("Pick a normal role (not @everyone or a bot role).")
        await self.bot.db.update_settings(interaction.guild_id, dj_role_id=role.id if role else None)  # type: ignore[arg-type]
        text = f"DJ role set to {role.mention}." if role else "Everyone can control the music."
        await interaction.response.send_message(embed=embeds.success(text), ephemeral=True)

    @settings.command(name="default-volume", description="Volume used when the bot joins")
    async def default_volume(self, interaction: discord.Interaction, level: app_commands.Range[int, 1, 1000]) -> None:
        maximum = self.bot.settings.max_volume
        if level > maximum:
            raise MusicError(f"The maximum allowed on this bot is {maximum}%.")
        await self.bot.db.update_settings(interaction.guild_id, volume=level)  # type: ignore[arg-type]
        await interaction.response.send_message(embed=embeds.success(f"Default volume is now **{level}%**."), ephemeral=True)

    @settings.command(name="announce", description="Post a now-playing message when each song starts")
    async def announce(self, interaction: discord.Interaction, enabled: bool) -> None:
        await self.bot.db.update_settings(interaction.guild_id, announce=int(enabled))  # type: ignore[arg-type]
        player = get_player(self.bot, interaction.guild_id or 0)
        if player is not None:
            player.announce = enabled
        await interaction.response.send_message(
            embed=embeds.success("Now-playing messages are " + ("on." if enabled else "off.")), ephemeral=True
        )


async def setup(bot: DripDropBot) -> None:
    await bot.add_cog(Admin(bot))
