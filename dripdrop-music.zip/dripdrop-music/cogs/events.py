"""Lavalink and Discord events: track changes, errors, auto-leave, reconnection, monitoring."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

import discord
import lavalink
from discord.ext import commands, tasks
from lavalink import EndReason, listener

from commands.checks import humans_in
from config import branding as b
from music import embeds
from music.player import MusicPlayer
from music.voice import get_player
from utils.formatting import clean, truncate

if TYPE_CHECKING:
    from bot.client import DripDropBot

log = logging.getLogger(__name__)

ALONE_LEAVE_SECONDS = 180
IDLE_LEAVE_SECONDS = 300
PANEL_REFRESH_SECONDS = 15


class Events(commands.Cog):
    def __init__(self, bot: DripDropBot):
        self.bot = bot
        bot.lavalink.add_event_hooks(self)
        self._alone_timers: dict[int, asyncio.Task] = {}
        self._was_offline = False
        self._autoplay_busy: set[int] = set()

    async def cog_load(self) -> None:
        self.monitor.start()
        self.panel_ticker.start()

    async def cog_unload(self) -> None:
        self.monitor.cancel()
        self.panel_ticker.cancel()
        for task in self._alone_timers.values():
            task.cancel()

    # ------------------------------------------------------------------ lavalink events
    @listener(lavalink.TrackStartEvent)
    async def on_track_start(self, event: lavalink.TrackStartEvent) -> None:
        player: MusicPlayer = event.player  # type: ignore[assignment]
        player.remember_started(event.track)
        self.bot.controller.persist(player)
        await self.bot.controller.post_panel(player, event.track)

    @listener(lavalink.TrackEndEvent)
    async def on_track_end(self, event: lavalink.TrackEndEvent) -> None:
        player: MusicPlayer = event.player  # type: ignore[assignment]
        player.record_finished(event.track, event.reason)

    @listener(lavalink.QueueEndEvent)
    async def on_queue_end(self, event: lavalink.QueueEndEvent) -> None:
        player: MusicPlayer = event.player  # type: ignore[assignment]
        if player.autoplay and player.guild_id not in self._autoplay_busy:
            self._autoplay_busy.add(player.guild_id)
            try:
                pick = await self.bot.music.autoplay_next(player)
                if pick is not None:
                    player.add(pick, requester=self.bot.user.id)  # type: ignore[union-attr]
                    await player.play()
                    return
            except lavalink.RequestError:
                log.warning("Autoplay could not start the next track", exc_info=True)
            finally:
                self._autoplay_busy.discard(player.guild_id)
        player.idle_since = time.monotonic()
        self.bot.controller.persist(player)
        await self.bot.controller.close_panel(player, "Queue finished. Add more with `/play`.")

    @listener(lavalink.TrackExceptionEvent)
    async def on_track_exception(self, event: lavalink.TrackExceptionEvent) -> None:
        await self._report_failure(event.player, event.track, event.message or "", event.cause)

    @listener(lavalink.TrackStuckEvent)
    async def on_track_stuck(self, event: lavalink.TrackStuckEvent) -> None:
        await self._report_failure(event.player, event.track, "stuck", "")

    async def _report_failure(self, player, track, message: str, cause: str) -> None:
        from music.service import explain_load_error

        name = truncate(clean(track.title), 80) if track else "that track"
        reason = explain_load_error(message, cause)
        log.warning("Track failed in guild %s (%s): %s %s", player.guild_id, name, message, cause)
        channel = self.bot.controller._text_channel(player)
        if channel is not None:
            try:
                await channel.send(embed=embeds.warning(f"Skipped **{name}**. {reason}"), delete_after=30)
            except discord.HTTPException:
                pass

    @listener(lavalink.NodeConnectedEvent)
    async def on_node_connected(self, event: lavalink.NodeConnectedEvent) -> None:
        log.info("Lavalink node %s connected", event.node.name)

    @listener(lavalink.NodeReadyEvent)
    async def on_node_ready(self, event: lavalink.NodeReadyEvent) -> None:
        log.info("Lavalink node %s ready (resumed=%s)", event.node.name, event.resumed)
        await self.bot.music.refresh_capabilities()
        if self._was_offline:
            self._was_offline = False
            # Players on a restarted server lost their voice state, so rebuild 24/7 sessions.
            await self.bot.controller.restore_always_on()

    @listener(lavalink.NodeDisconnectedEvent)
    async def on_node_disconnected(self, event: lavalink.NodeDisconnectedEvent) -> None:
        self._was_offline = True
        log.warning("Lavalink node %s disconnected (code=%s reason=%s)", event.node.name, event.code, event.reason)

    @listener(lavalink.WebSocketClosedEvent)
    async def on_voice_closed(self, event: lavalink.WebSocketClosedEvent) -> None:
        log.warning("Discord voice socket closed in guild %s: code=%s reason=%s", event.player.guild_id, event.code, event.reason)

    # ------------------------------------------------------------------ discord events
    @commands.Cog.listener()
    async def on_voice_state_update(
        self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState
    ) -> None:
        guild = member.guild
        player = get_player(self.bot, guild.id)

        if member.id == self.bot.user.id:  # type: ignore[union-attr]
            if before.channel and after.channel is None and player is not None:
                await self._saved_leave(guild, player)
            elif after.channel and player is not None:
                if after.channel != before.channel:
                    await self.bot.db.update_settings(guild.id, voice_channel_id=after.channel.id) if player.always_on else None
                if isinstance(after.channel, discord.StageChannel) and guild.me.voice and guild.me.voice.suppress:
                    try:
                        await guild.me.edit(suppress=False)
                    except discord.HTTPException:
                        log.info("Could not become a stage speaker in guild %s", guild.id)
            return

        if player is None or not player.is_connected or player.channel_id is None:
            return
        channel = guild.get_channel(player.channel_id)
        if channel is None or channel not in (before.channel, after.channel):
            return
        if humans_in(channel):  # type: ignore[arg-type]
            self._cancel_alone(guild.id)
            if player.paused and player.current is not None and not player.always_on and getattr(player, "auto_paused", False):
                player.auto_paused = False  # type: ignore[attr-defined]
                await player.set_pause(False)
                await self.bot.controller.refresh_panel(player)
        elif not player.always_on:
            self._start_alone(guild, player)

    async def _saved_leave(self, guild: discord.Guild, player: MusicPlayer) -> None:
        """The bot was disconnected (kicked or channel deleted). Save state and clean up."""
        self._cancel_alone(guild.id)
        self.bot.controller.persist(player)
        await self.bot.controller.close_panel(player, "I was disconnected from voice.")
        try:
            await self.bot.lavalink.player_manager.destroy(guild.id)
        except lavalink.ClientError:
            pass

    def _cancel_alone(self, guild_id: int) -> None:
        task = self._alone_timers.pop(guild_id, None)
        if task:
            task.cancel()

    def _start_alone(self, guild: discord.Guild, player: MusicPlayer) -> None:
        if guild.id in self._alone_timers:
            return
        self._alone_timers[guild.id] = asyncio.create_task(self._alone_timeout(guild, player))

    async def _alone_timeout(self, guild: discord.Guild, player: MusicPlayer) -> None:
        try:
            if player.current is not None and not player.paused:
                player.auto_paused = True  # type: ignore[attr-defined]
                await player.set_pause(True)
                await self.bot.controller.refresh_panel(player)
            await asyncio.sleep(ALONE_LEAVE_SECONDS)
            channel = guild.get_channel(player.channel_id) if player.channel_id else None
            if channel is not None and not humans_in(channel):  # type: ignore[arg-type]
                log.info("Leaving guild %s: alone for %ss", guild.id, ALONE_LEAVE_SECONDS)
                await self.bot.controller.leave(guild, forget=False)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001
            log.exception("Alone-timeout failed in guild %s", guild.id)
        finally:
            self._alone_timers.pop(guild.id, None)

    # ------------------------------------------------------------------ background loops
    @tasks.loop(seconds=30)
    async def monitor(self) -> None:
        """Connection watchdog: log outages, reconnect 24/7 guilds, leave after long idle."""
        online = self.bot.music.online
        if not online:
            if not self._was_offline:
                log.warning("Lavalink is unreachable. Waiting for it to come back.")
            self._was_offline = True
            return
        if self._was_offline:
            self._was_offline = False
            await self.bot.music.refresh_capabilities()
        await self.bot.controller.restore_always_on()

        now = time.monotonic()
        for guild in self.bot.guilds:
            player = get_player(self.bot, guild.id)
            if player is None or not player.is_connected or player.always_on:
                continue
            if player.current is None and player.idle_since and now - player.idle_since > IDLE_LEAVE_SECONDS:
                log.info("Leaving guild %s: idle for %ss", guild.id, IDLE_LEAVE_SECONDS)
                await self.bot.controller.leave(guild, forget=False)

    @monitor.before_loop
    async def _before_monitor(self) -> None:
        await self.bot.wait_until_ready()
        await asyncio.sleep(10)  # give Lavalink a moment to connect

    @monitor.error
    async def _monitor_error(self, error: BaseException) -> None:
        log.error("Monitor loop crashed; restarting", exc_info=error)
        self.monitor.restart()

    @tasks.loop(seconds=PANEL_REFRESH_SECONDS)
    async def panel_ticker(self) -> None:
        """Keep the progress bar moving on active panels."""
        for player in list(self.bot.lavalink.player_manager.values()):
            if player.current is not None and not player.paused and player.panel_message_id:
                await self.bot.controller.refresh_panel(player)  # type: ignore[arg-type]

    @panel_ticker.before_loop
    async def _before_ticker(self) -> None:
        await self.bot.wait_until_ready()

    @panel_ticker.error
    async def _ticker_error(self, error: BaseException) -> None:
        log.error("Panel ticker crashed; restarting", exc_info=error)
        self.panel_ticker.restart()


async def setup(bot: DripDropBot) -> None:
    await bot.add_cog(Events(bot))
