"""Information commands: /nowplaying /lyrics /playlist /help."""

from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from commands.checks import control_player, require_voice
from music import embeds
from music.errors import MusicError, NothingFound
from music.tracks import deserialize_many, serialize_many
from music.views import LyricsView, PlayerView
from services.lyrics import Lyrics, find_lyrics

if TYPE_CHECKING:
    from bot.client import DripDropBot

MAX_SAVE_TRACKS = 200


async def playlist_names(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
    bot: DripDropBot = interaction.client  # type: ignore[assignment]
    rows = await bot.db.list_playlists(interaction.user.id)
    needle = current.strip().lower()
    return [app_commands.Choice(name=f"{r['name']} ({r['tracks']})", value=r["name"]) for r in rows if needle in r["name"].lower()][:25]


class Info(commands.Cog):
    playlist = app_commands.Group(name="playlist", description="Import links and manage your saved playlists", guild_only=True)

    def __init__(self, bot: DripDropBot):
        self.bot = bot

    @app_commands.command(name="nowplaying", description="Show the current song")
    @app_commands.guild_only()
    async def nowplaying(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction, dj=False, need_track=True)
        await interaction.response.send_message(
            embed=embeds.now_playing(player, self.bot.user.id), view=PlayerView(self.bot, player)  # type: ignore[union-attr]
        )

    @app_commands.command(name="lyrics", description="Show lyrics for the current song or any song")
    @app_commands.describe(query="Song to look up (leave empty to use the current song)")
    async def lyrics(self, interaction: discord.Interaction, query: str | None = None) -> None:
        title = author = ""
        duration = 0
        if query:
            if len(query) > 200:
                raise MusicError("Keep the search under 200 characters.")
            title = query
        else:
            player = self.bot.lavalink.player_manager.get(interaction.guild_id) if interaction.guild_id else None
            if player is None or player.current is None:
                raise MusicError("Nothing is playing. Use `/lyrics song name` to look one up.")
            title, author, duration = player.current.title, player.current.author, player.current.duration
        await interaction.response.defer()
        found: Lyrics | None = await find_lyrics(self.bot.http_session, title, author, duration)  # type: ignore[arg-type]
        if found is None:
            raise NothingFound("I couldn't find lyrics for that. Try `/lyrics Artist - Song`.")
        view = LyricsView(found, interaction.user.id)
        view.interaction = interaction
        await interaction.followup.send(embed=view.render(), view=view)

    @app_commands.command(name="help", description="What I can do and which platforms work")
    async def help(self, interaction: discord.Interaction) -> None:
        caps = await self.bot.music.ensure_caps() if self.bot.music.online else self.bot.music.caps
        await interaction.response.send_message(embed=embeds.help_embed(caps, self.bot.music.online), ephemeral=True)

    # ------------------------------------------------------------------ /playlist
    @playlist.command(name="import", description="Add a playlist, album or mix from a link to the queue")
    @app_commands.describe(link="A playlist/album link from YouTube, Spotify, SoundCloud, Apple Music, Deezer, Bandcamp...", shuffle="Shuffle before adding")
    async def playlist_import(self, interaction: discord.Interaction, link: str, shuffle: bool = False) -> None:
        require_voice(interaction)
        await interaction.response.defer()
        resolved = await self.bot.music.resolve(link, requester=interaction.user.id)
        if resolved.kind == "search":
            raise MusicError("Paste a link to a playlist or album. For a song name use `/play`.")
        if shuffle and resolved.kind == "playlist":
            import random

            random.shuffle(resolved.tracks)
        embed = await self.bot.controller.enqueue(interaction, resolved)
        await interaction.followup.send(embed=embed)

    @playlist.command(name="save", description="Save the current queue as one of your playlists")
    @app_commands.describe(name="A name for the playlist")
    async def playlist_save(self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 50]) -> None:
        player = await control_player(self.bot, interaction, dj=False)
        tracks = ([player.current] if player.current else []) + list(player.queue)
        if not tracks:
            raise MusicError("There's nothing to save. Add some songs first.")
        try:
            outcome = await self.bot.db.save_playlist(interaction.user.id, name, serialize_many(tracks, MAX_SAVE_TRACKS))
        except ValueError as exc:
            raise MusicError(str(exc)) from None
        verb = "Saved" if outcome == "created" else "Updated"
        await interaction.response.send_message(
            embed=embeds.success(f"{verb} **{embeds.clean(name)}** with {min(len(tracks), MAX_SAVE_TRACKS)} tracks."),
            ephemeral=True,
        )

    @playlist.command(name="load", description="Add one of your saved playlists to the queue")
    @app_commands.describe(name="Playlist name", shuffle="Shuffle before adding")
    @app_commands.autocomplete(name=playlist_names)
    async def playlist_load(self, interaction: discord.Interaction, name: str, shuffle: bool = False) -> None:
        require_voice(interaction)
        stored = await self.bot.db.get_playlist(interaction.user.id, name)
        if stored is None:
            raise NothingFound(f"You don't have a playlist called **{embeds.clean(name)}**. See `/playlist list`.")
        tracks = deserialize_many(stored)
        if not tracks:
            raise MusicError("That playlist couldn't be read.")
        if shuffle:
            import random

            random.shuffle(tracks)
        await interaction.response.defer()
        embed = await self.bot.controller.enqueue_tracks(interaction, tracks, title=name, as_playlist=True)
        await interaction.followup.send(embed=embed)

    @playlist.command(name="list", description="Show your saved playlists")
    async def playlist_list(self, interaction: discord.Interaction) -> None:
        rows = await self.bot.db.list_playlists(interaction.user.id)
        if not rows:
            text = "You haven't saved any playlists yet. Queue some songs and use `/playlist save`."
        else:
            text = "\n".join(f"• **{embeds.clean(r['name'])}** · {r['tracks']} tracks" for r in rows)
        await interaction.response.send_message(embed=embeds.info(text, title="Your playlists"), ephemeral=True)

    @playlist.command(name="delete", description="Delete one of your saved playlists")
    @app_commands.autocomplete(name=playlist_names)
    async def playlist_delete(self, interaction: discord.Interaction, name: str) -> None:
        if not await self.bot.db.delete_playlist(interaction.user.id, name):
            raise NothingFound(f"You don't have a playlist called **{embeds.clean(name)}**.")
        await interaction.response.send_message(embed=embeds.success(f"Deleted **{embeds.clean(name)}**."), ephemeral=True)


async def setup(bot: DripDropBot) -> None:
    await bot.add_cog(Info(bot))
