"""Queue commands: /queue /clear /shuffle /remove /move /loop /autoplay."""

from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from commands.autocomplete import queue_position
from commands.checks import control_player
from config import branding as b
from music import embeds
from music.errors import MusicError
from music.views import QueueView

if TYPE_CHECKING:
    from bot.client import DripDropBot


class Queue(commands.Cog):
    def __init__(self, bot: DripDropBot):
        self.bot = bot

    @app_commands.command(name="queue", description="Show the queue")
    @app_commands.describe(page="Page number")
    @app_commands.guild_only()
    async def queue(self, interaction: discord.Interaction, page: app_commands.Range[int, 1, 500] = 1) -> None:
        player = await control_player(self.bot, interaction, dj=False)
        view = QueueView(self.bot, interaction.guild_id or 0, interaction.user.id, page)
        view.interaction = interaction
        await interaction.response.send_message(embed=embeds.queue_page(player, self.bot.user.id, page), view=view)  # type: ignore[union-attr]

    @app_commands.command(name="clear", description="Remove every song from the queue (keeps the current song)")
    @app_commands.guild_only()
    async def clear(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction)
        removed = player.clear()
        if not removed:
            raise MusicError("The queue is already empty.")
        self.bot.controller.persist(player)
        await interaction.response.send_message(embed=embeds.success(f"Cleared {removed} tracks."))

    @app_commands.command(name="shuffle", description="Mix up the queue")
    @app_commands.guild_only()
    async def shuffle(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction)
        if len(player.queue) < 2:
            raise MusicError("Add at least two songs to the queue to shuffle.")
        player.shuffle_queue()
        self.bot.controller.persist(player)
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_SHUFFLE} Shuffled {len(player.queue)} tracks."))

    @app_commands.command(name="remove", description="Remove a song from the queue")
    @app_commands.describe(position="Position in the queue (see /queue)")
    @app_commands.autocomplete(position=queue_position)
    @app_commands.guild_only()
    async def remove(self, interaction: discord.Interaction, position: app_commands.Range[int, 1, 5000]) -> None:
        player = await control_player(self.bot, interaction)
        try:
            track = player.remove(position)
        except IndexError:
            raise MusicError(f"There's no song at position {position}. The queue has {len(player.queue)}.") from None
        self.bot.controller.persist(player)
        await interaction.response.send_message(embed=embeds.success(f"Removed **{embeds.clean(track.title)}**."))

    @app_commands.command(name="move", description="Move a song to another position in the queue")
    @app_commands.describe(position="Where the song is now", to="Where to put it (1 = next)")
    @app_commands.autocomplete(position=queue_position)
    @app_commands.guild_only()
    async def move(
        self,
        interaction: discord.Interaction,
        position: app_commands.Range[int, 1, 5000],
        to: app_commands.Range[int, 1, 5000],
    ) -> None:
        player = await control_player(self.bot, interaction)
        try:
            track = player.move(position, to)
        except IndexError:
            raise MusicError(f"Positions must be between 1 and {len(player.queue)}.") from None
        self.bot.controller.persist(player)
        await interaction.response.send_message(
            embed=embeds.success(f"Moved **{embeds.clean(track.title)}** to position {to}.")
        )

    @app_commands.command(name="loop", description="Repeat the current song or the whole queue")
    @app_commands.describe(mode="What to repeat")
    @app_commands.choices(
        mode=[
            app_commands.Choice(name="Off", value=0),
            app_commands.Choice(name="Current track", value=1),
            app_commands.Choice(name="Whole queue", value=2),
        ]
    )
    @app_commands.guild_only()
    async def loop(self, interaction: discord.Interaction, mode: app_commands.Choice[int]) -> None:
        player = await control_player(self.bot, interaction)
        player.loop = mode.value
        await self.bot.db.update_settings(interaction.guild_id, loop_mode=mode.value)  # type: ignore[arg-type]
        self.bot.controller.persist(player)
        await interaction.response.send_message(embed=embeds.success(f"Loop: **{embeds.loop_text(player)}**"))
        await self.bot.controller.refresh_panel(player)

    @app_commands.command(name="autoplay", description="Keep similar songs coming when the queue ends")
    @app_commands.describe(enabled="Turn autoplay on or off")
    @app_commands.guild_only()
    async def autoplay(self, interaction: discord.Interaction, enabled: bool) -> None:
        player = await control_player(self.bot, interaction)
        player.autoplay = enabled
        await self.bot.db.update_settings(interaction.guild_id, autoplay=int(enabled))  # type: ignore[arg-type]
        text = "on. I'll queue similar songs when the queue ends." if enabled else "off."
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_AUTOPLAY} Autoplay is {text}"))
        await self.bot.controller.refresh_panel(player)


async def setup(bot: DripDropBot) -> None:
    await bot.add_cog(Queue(bot))
