"""Playback commands: /play /pause /resume /skip /stop /previous /seek /volume."""

from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from commands.checks import control_player, require_voice
from config import branding as b
from music import embeds
from music.errors import MusicError
from music.views import SearchView
from utils.formatting import format_duration, parse_timestamp
from utils.urls import SEARCH_PREFIXES

if TYPE_CHECKING:
    from bot.client import DripDropBot

SOURCE_CHOICES = [
    app_commands.Choice(name="YouTube (default)", value="youtube"),
    app_commands.Choice(name="YouTube Music", value="youtube_music"),
    app_commands.Choice(name="SoundCloud", value="soundcloud"),
    app_commands.Choice(name="Spotify", value="spotify"),
    app_commands.Choice(name="Apple Music", value="apple_music"),
]
assert {c.value for c in SOURCE_CHOICES} <= set(SEARCH_PREFIXES)


class Playback(commands.Cog):
    def __init__(self, bot: DripDropBot):
        self.bot = bot

    @app_commands.command(name="play", description="Play a song, link or playlist (YouTube, Spotify, SoundCloud and more)")
    @app_commands.describe(
        query="A song name or a link",
        source="Where to search when you type a name (default YouTube)",
        next="Play it right after the current song",
    )
    @app_commands.choices(source=SOURCE_CHOICES)
    @app_commands.guild_only()
    async def play(
        self,
        interaction: discord.Interaction,
        query: str,
        source: app_commands.Choice[str] | None = None,
        next: bool = False,
    ) -> None:
        require_voice(interaction)
        await interaction.response.defer()
        resolved = await self.bot.music.resolve(
            query, source.value if source else "youtube", requester=interaction.user.id
        )
        embed = await self.bot.controller.enqueue(interaction, resolved, play_next=next)
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="pause", description="Pause the music")
    @app_commands.guild_only()
    async def pause(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction, need_track=True)
        if player.paused:
            raise MusicError("Already paused. Use `/resume` to continue.")
        await player.set_pause(True)
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_PAUSE} Paused."))
        await self.bot.controller.refresh_panel(player)

    @app_commands.command(name="resume", description="Resume the music")
    @app_commands.guild_only()
    async def resume(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction, need_track=True)
        if not player.paused:
            raise MusicError("The music isn't paused.")
        await player.set_pause(False)
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_PLAY} Resumed."))
        await self.bot.controller.refresh_panel(player)

    @app_commands.command(name="skip", description="Skip the current song")
    @app_commands.guild_only()
    async def skip(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction, need_track=True)
        title = embeds.clean(player.current.title)  # type: ignore[union-attr]
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_SKIP} Skipped **{title}**."))
        await player.skip_track()

    @app_commands.command(name="previous", description="Go back to the previous song")
    @app_commands.guild_only()
    async def previous(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction)
        track = await player.play_previous()
        if track is None:
            raise MusicError("There's no previous song yet.")
        await interaction.response.send_message(
            embed=embeds.success(f"{b.ICON_PREVIOUS} Back to **{embeds.clean(track.title)}**.")
        )

    @app_commands.command(name="stop", description="Stop the music, clear the queue and leave")
    @app_commands.guild_only()
    async def stop(self, interaction: discord.Interaction) -> None:
        player = await control_player(self.bot, interaction)
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_STOP} Stopped and cleared the queue."))
        await self.bot.controller.stop(interaction.guild, player)  # type: ignore[arg-type]

    @app_commands.command(name="seek", description="Jump to a time in the current song")
    @app_commands.describe(time="For example 90, 1:30 or 1m30s")
    @app_commands.guild_only()
    async def seek(self, interaction: discord.Interaction, time: str) -> None:
        player = await control_player(self.bot, interaction, need_track=True)
        track = player.current
        assert track is not None
        if track.is_stream or not track.is_seekable:
            raise MusicError("This is a live stream, so I can't seek in it.")
        target = parse_timestamp(time)
        if target is None:
            raise MusicError("I didn't understand that time. Try `90`, `1:30` or `1m30s`.")
        if target >= track.duration:
            raise MusicError(f"That's past the end. This song is {format_duration(track.duration)} long.")
        await player.seek(target)
        await interaction.response.send_message(embed=embeds.success(f"Jumped to `{format_duration(target)}`."))

    @app_commands.command(name="volume", description="Show or change the volume")
    @app_commands.describe(level="0 to the server maximum. Leave empty to show the current volume")
    @app_commands.guild_only()
    async def volume(self, interaction: discord.Interaction, level: int | None = None) -> None:
        if level is None:
            player = await control_player(self.bot, interaction, dj=False)
            await interaction.response.send_message(embed=embeds.info(f"{b.ICON_VOLUME} Volume is **{player.volume}%**."))
            return
        maximum = self.bot.settings.max_volume
        if not 0 <= level <= maximum:
            raise MusicError(f"Pick a volume between 0 and {maximum}.")
        player = await control_player(self.bot, interaction)
        await player.set_volume(level)
        await self.bot.db.update_settings(interaction.guild_id, volume=level)  # type: ignore[arg-type]
        warn = " High volumes can distort the sound." if level > 100 else ""
        await interaction.response.send_message(embed=embeds.success(f"{b.ICON_VOLUME} Volume set to **{level}%**.{warn}"))
        await self.bot.controller.refresh_panel(player)

    @app_commands.command(name="search", description="Search for a song and pick from the results")
    @app_commands.describe(query="What to search for", source="Where to search (default YouTube)", next="Play the pick(s) next")
    @app_commands.choices(source=SOURCE_CHOICES)
    @app_commands.guild_only()
    async def search(
        self,
        interaction: discord.Interaction,
        query: str,
        source: app_commands.Choice[str] | None = None,
        next: bool = False,
    ) -> None:
        require_voice(interaction)
        await interaction.response.defer()
        resolved = await self.bot.music.resolve(query, source.value if source else "youtube", requester=interaction.user.id)
        if resolved.kind != "search":  # they pasted a link: just play it
            embed = await self.bot.controller.enqueue(interaction, resolved, play_next=next)
            await interaction.followup.send(embed=embed)
            return
        view = SearchView(self.bot, interaction.user.id, resolved.tracks, play_next=next)
        view.interaction = interaction
        await interaction.followup.send(embed=embeds.search_results(query, resolved.tracks), view=view)


async def setup(bot: DripDropBot) -> None:
    await bot.add_cog(Playback(bot))
