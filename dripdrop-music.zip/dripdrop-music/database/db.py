"""SQLite storage: per-server settings, saved queues and user playlists.

Uses the standard library only. All queries are parameterised. Blocking sqlite calls run in a
worker thread so they never stall the bot's event loop.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

MAX_PLAYLISTS_PER_USER = 25
MAX_TRACKS_PER_PLAYLIST = 200

_SCHEMA = """
CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id        INTEGER PRIMARY KEY,
    volume          INTEGER NOT NULL DEFAULT 60,
    dj_role_id      INTEGER,
    always_on       INTEGER NOT NULL DEFAULT 0,
    autoplay        INTEGER NOT NULL DEFAULT 0,
    loop_mode       INTEGER NOT NULL DEFAULT 0,
    announce        INTEGER NOT NULL DEFAULT 1,
    voice_channel_id INTEGER,
    text_channel_id INTEGER
);
CREATE TABLE IF NOT EXISTS queue_state (
    guild_id   INTEGER PRIMARY KEY,
    data       TEXT NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS playlists (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    name       TEXT NOT NULL COLLATE NOCASE,
    tracks     TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE (user_id, name)
);
"""

_SETTING_FIELDS = {
    "volume", "dj_role_id", "always_on", "autoplay", "loop_mode", "announce",
    "voice_channel_id", "text_channel_id",
}


class Database:
    def __init__(self, path: Path | str):
        self.path = str(path)
        self._conn: sqlite3.Connection | None = None
        self._lock = threading.Lock()

    # -- lifecycle -----------------------------------------------------------------
    async def connect(self) -> None:
        await asyncio.to_thread(self._connect)

    def _connect(self) -> None:
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(_SCHEMA)
        conn.commit()
        self._conn = conn

    async def close(self) -> None:
        await asyncio.to_thread(self._close)

    def _close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None

    async def _run(self, sql: str, params: tuple = (), *, fetch: str = "none") -> Any:
        return await asyncio.to_thread(self._execute, sql, params, fetch)

    def _execute(self, sql: str, params: tuple, fetch: str) -> Any:
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Database is not connected")
            cur = self._conn.execute(sql, params)
            result: Any = None
            if fetch == "one":
                row = cur.fetchone()
                result = dict(row) if row else None
            elif fetch == "all":
                result = [dict(r) for r in cur.fetchall()]
            elif fetch == "rowcount":
                result = cur.rowcount
            self._conn.commit()
            return result

    # -- guild settings --------------------------------------------------------------
    async def get_settings(self, guild_id: int, *, default_volume: int = 60) -> dict[str, Any]:
        row = await self._run("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,), fetch="one")
        if row is None:
            await self._run(
                "INSERT OR IGNORE INTO guild_settings (guild_id, volume) VALUES (?, ?)",
                (guild_id, default_volume),
            )
            row = await self._run("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,), fetch="one")
        return row

    async def update_settings(self, guild_id: int, **fields: Any) -> None:
        if not fields:
            return
        unknown = set(fields) - _SETTING_FIELDS
        if unknown:
            raise ValueError(f"Unknown setting(s): {', '.join(sorted(unknown))}")
        await self._run("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
        columns = ", ".join(f"{name} = ?" for name in fields)  # names are whitelisted above
        await self._run(
            f"UPDATE guild_settings SET {columns} WHERE guild_id = ?",
            (*fields.values(), guild_id),
        )

    async def always_on_guilds(self) -> list[dict[str, Any]]:
        return await self._run(
            "SELECT * FROM guild_settings WHERE always_on = 1 AND voice_channel_id IS NOT NULL",
            fetch="all",
        )

    # -- queue persistence ---------------------------------------------------------------
    async def save_queue(self, guild_id: int, state: dict[str, Any]) -> None:
        await self._run(
            "INSERT INTO queue_state (guild_id, data, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at",
            (guild_id, json.dumps(state, separators=(",", ":")), int(time.time())),
        )

    async def load_queue(self, guild_id: int) -> dict[str, Any] | None:
        row = await self._run("SELECT data FROM queue_state WHERE guild_id = ?", (guild_id,), fetch="one")
        if row is None:
            return None
        try:
            return json.loads(row["data"])
        except json.JSONDecodeError:
            return None

    async def clear_queue_state(self, guild_id: int) -> None:
        await self._run("DELETE FROM queue_state WHERE guild_id = ?", (guild_id,))

    # -- user playlists --------------------------------------------------------------------
    async def save_playlist(self, user_id: int, name: str, tracks: list[dict[str, Any]]) -> str:
        """Returns 'created', 'updated', or raises ValueError for limits."""
        name = name.strip()
        if not 1 <= len(name) <= 50:
            raise ValueError("Playlist names must be 1 to 50 characters.")
        if not tracks:
            raise ValueError("There are no tracks to save.")
        tracks = tracks[:MAX_TRACKS_PER_PLAYLIST]
        existing = await self._run(
            "SELECT id FROM playlists WHERE user_id = ? AND name = ?", (user_id, name), fetch="one"
        )
        payload = json.dumps(tracks, separators=(",", ":"))
        if existing:
            await self._run("UPDATE playlists SET tracks = ? WHERE id = ?", (payload, existing["id"]))
            return "updated"
        count = await self._run(
            "SELECT COUNT(*) AS n FROM playlists WHERE user_id = ?", (user_id,), fetch="one"
        )
        if count["n"] >= MAX_PLAYLISTS_PER_USER:
            raise ValueError(f"You can save up to {MAX_PLAYLISTS_PER_USER} playlists. Delete one first.")
        await self._run(
            "INSERT INTO playlists (user_id, name, tracks, created_at) VALUES (?, ?, ?, ?)",
            (user_id, name, payload, int(time.time())),
        )
        return "created"

    async def get_playlist(self, user_id: int, name: str) -> list[dict[str, Any]] | None:
        row = await self._run(
            "SELECT tracks FROM playlists WHERE user_id = ? AND name = ?", (user_id, name.strip()), fetch="one"
        )
        if row is None:
            return None
        try:
            return json.loads(row["tracks"])
        except json.JSONDecodeError:
            return None

    async def list_playlists(self, user_id: int) -> list[dict[str, Any]]:
        rows = await self._run(
            "SELECT name, tracks FROM playlists WHERE user_id = ? ORDER BY name", (user_id,), fetch="all"
        )
        out = []
        for row in rows:
            try:
                size = len(json.loads(row["tracks"]))
            except json.JSONDecodeError:
                size = 0
            out.append({"name": row["name"], "tracks": size})
        return out

    async def delete_playlist(self, user_id: int, name: str) -> bool:
        removed = await self._run(
            "DELETE FROM playlists WHERE user_id = ? AND name = ?", (user_id, name.strip()), fetch="rowcount"
        )
        return bool(removed)
