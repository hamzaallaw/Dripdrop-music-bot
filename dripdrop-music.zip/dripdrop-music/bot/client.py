"""The bot itself: wires Discord, Lavalink, the database and all cogs together."""

from __future__ import annotations

import logging

import aiohttp
import discord
import lavalink
from discord import app_commands
from discord.ext import commands

from commands.errors import handle_app_command_error
from config import branding
from config.settings import Settings
from database.db import Database
from music.controller import MusicController
from music.player import MusicPlayer
from music.service import MusicService
from music.views import PlayerView
from utils.ratelimit import SpamGuard

log = logging.getLogger(__name__)

EXTENSIONS = (
    "cogs.events",
    "cogs.playback",
    "cogs.queue",
    "cogs.info",
    "cogs.admin",
)
USER_AGENT = "DripDropMusic/1.0 (Discord music bot)"


class DripDropTree(app_commands.CommandTree):
    """Applies the anti-spam limit to every slash command and handles errors in one place."""

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        bot: DripDropBot = interaction.client  # type: ignore[assignment]
        wait = bot.spam_guard.check(interaction.user.id)
        if wait > 0:
            from commands.errors import send_error

            await send_error(interaction, f"Slow down! Try again in {wait:.0f}s.")
            return False
        return True

    async def on_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
        await handle_app_command_error(interaction, error)


class DripDropBot(commands.Bot):
    def __init__(self, settings: Settings):
        intents = discord.Intents.default()  # guilds + voice_states; no privileged intents needed
        super().__init__(
            command_prefix=commands.when_mentioned,  # slash commands only
            intents=intents,
            help_command=None,
            tree_cls=DripDropTree,
            activity=discord.Activity(type=discord.ActivityType.listening, name="/play · " + branding.NAME),
            allowed_mentions=discord.AllowedMentions.none(),
            member_cache_flags=discord.MemberCacheFlags.from_intents(intents),
        )
        self.settings = settings
        self.db = Database(settings.database_path)
        self.spam_guard = SpamGuard(rate=6, per=10.0)
        self.http_session: aiohttp.ClientSession | None = None
        self.lavalink: lavalink.Client = None  # type: ignore[assignment]
        self.music: MusicService = None  # type: ignore[assignment]
        self.controller = MusicController(self)

    async def setup_hook(self) -> None:
        await self.db.connect()
        self.http_session = aiohttp.ClientSession(headers={"User-Agent": USER_AGENT})

        # setup_hook runs after login, so the bot's user id is already known here.
        self.lavalink = lavalink.Client(self.user.id, player=MusicPlayer)  # type: ignore[union-attr]
        self.music = MusicService(self.lavalink, self.http_session, self.settings)
        s = self.settings
        self.lavalink.add_node(
            host=s.lavalink_host, port=s.lavalink_port, password=s.lavalink_password,
            region="eu", name="main", ssl=s.lavalink_ssl,
        )

        for ext in EXTENSIONS:
            await self.load_extension(ext)
        self.add_view(PlayerView(self))  # keep panels from before a restart working

        if self.settings.dev_guild_id:
            guild = discord.Object(self.settings.dev_guild_id)
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Synced %d commands to dev guild %s", len(synced), guild.id)
        else:
            synced = await self.tree.sync()
            log.info("Synced %d global commands (can take up to an hour to appear everywhere)", len(synced))

    async def on_ready(self) -> None:
        log.info("DripDrop Music online as %s in %d servers", self.user, len(self.guilds))

    async def close(self) -> None:
        for player in list(self.lavalink.player_manager.values()) if self.lavalink else []:
            try:
                self.controller.persist(player)
            except Exception:  # noqa: BLE001
                log.debug("Could not save queue during shutdown", exc_info=True)
        if self.controller._tasks:
            import asyncio

            await asyncio.gather(*self.controller._tasks, return_exceptions=True)
        if self.lavalink is not None:
            await self.lavalink.close()
        if self.http_session is not None:
            await self.http_session.close()
        await self.db.close()
        await super().close()
