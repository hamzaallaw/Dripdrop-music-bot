"""Discord voice connection that hands the audio job to Lavalink.

Discord does not let a bot send audio through Lavalink directly. Instead the bot joins the
voice channel normally, then forwards Discord's voice server details to Lavalink, which
connects to Discord's voice servers and streams the audio itself (including DAVE
end-to-end encryption on Lavalink 4.2+).
"""

from __future__ import annotations

import logging
from typing import Any

import discord
import lavalink
from discord import VoiceProtocol

from music.player import MusicPlayer

log = logging.getLogger(__name__)


class LavalinkVoiceClient(VoiceProtocol):
    def __init__(self, client: discord.Client, channel: discord.abc.Connectable):
        super().__init__(client, channel)
        self.client = client
        self.channel = channel
        self.guild_id = channel.guild.id
        self._destroyed = False
        self.lavalink: lavalink.Client = client.lavalink  # type: ignore[attr-defined]

    async def on_voice_server_update(self, data: dict[str, Any]) -> None:
        await self.lavalink.voice_update_handler({"t": "VOICE_SERVER_UPDATE", "d": data})

    async def on_voice_state_update(self, data: dict[str, Any]) -> None:
        channel_id = data.get("channel_id")
        if not channel_id:
            await self._destroy()
            return
        found = self.client.get_channel(int(channel_id))
        if found is not None:
            self.channel = found
        await self.lavalink.voice_update_handler({"t": "VOICE_STATE_UPDATE", "d": data})

    async def connect(
        self, *, timeout: float, reconnect: bool, self_deaf: bool = True, self_mute: bool = False
    ) -> None:
        self.lavalink.player_manager.create(guild_id=self.channel.guild.id)
        await self.channel.guild.change_voice_state(
            channel=self.channel, self_mute=self_mute, self_deaf=True
        )

    async def disconnect(self, *, force: bool = False) -> None:
        player = self.lavalink.player_manager.get(self.channel.guild.id)
        if not force and (player is None or not player.is_connected):
            return
        await self.channel.guild.change_voice_state(channel=None)
        if player is not None:
            player.channel_id = None
        await self._destroy()

    async def _destroy(self) -> None:
        self.cleanup()
        if self._destroyed:
            return
        self._destroyed = True
        try:
            await self.lavalink.player_manager.destroy(self.guild_id)
        except lavalink.ClientError:
            log.debug("Player for guild %s was already gone", self.guild_id)


def get_player(bot: discord.Client, guild_id: int) -> MusicPlayer | None:
    return bot.lavalink.player_manager.get(guild_id)  # type: ignore[attr-defined,return-value]
