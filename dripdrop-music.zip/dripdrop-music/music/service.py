"""High-level music operations: turn user input into playable tracks, and pick autoplay tracks.

Everything here is free of Discord objects so it can be unit-tested with a fake Lavalink client.
"""

from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass, field
from typing import Any

import aiohttp
import lavalink
from lavalink import AudioTrack, LoadType

from config.settings import Settings
from music.capabilities import Capabilities
from music.errors import MusicError, NodeUnavailable, NothingFound, SourceUnavailable
from music.lazy import LazySearchTrack
from music.player import MusicPlayer
from services import deezer
from services.lyrics import clean_artist
from utils.urls import (
    SEARCH_PREFIXES,
    Platform,
    build_identifier,
    detect_platform,
    ensure_public_host,
    has_other_scheme,
    is_url,
    validate_url,
)

log = logging.getLogger(__name__)

MAX_QUERY_LENGTH = 500
SEARCH_RESULT_LIMIT = 10

_NETWORK_ERRORS = (
    lavalink.RequestError,
    lavalink.ClientError,
    aiohttp.ClientError,
    asyncio.TimeoutError,
    OSError,
)


@dataclass
class Resolved:
    kind: str  # "track" | "playlist" | "search"
    tracks: list[AudioTrack]
    title: str = ""
    platform: Platform | None = None
    note: str = ""
    extra: dict[str, Any] = field(default_factory=dict)


def explain_load_error(message: str, cause: str = "") -> str:
    """Turn Lavalink's technical failure text into something a user can act on."""
    text = f"{message} {cause}".lower()
    if "confirm you" in text and "bot" in text or "sign in" in text:
        return (
            "YouTube is blocking the music server right now (it asked to confirm it's not a bot). "
            "The bot owner needs to enable YouTube OAuth or a poToken. Other platforms still work."
        )
    if "age" in text and "restrict" in text:
        return "That video is age-restricted, so I can't play it."
    if "private" in text:
        return "That video or playlist is private."
    if "unavailable" in text or "not available" in text or "blocked" in text:
        return "That track isn't available (it may be removed or blocked in this region)."
    if "copyright" in text:
        return "That track can't be played because of a copyright restriction."
    if "premium" in text or "drm" in text:
        return "That track is protected and can't be streamed."
    return "I couldn't load that. Try a different link or search for it by name."


class MusicService:
    def __init__(self, client: lavalink.Client, session: aiohttp.ClientSession, settings: Settings):
        self.client = client
        self.session = session
        self.settings = settings
        self.caps: Capabilities | None = None

    # ------------------------------------------------------------------ node info
    def node(self) -> lavalink.Node:
        nodes = self.client.node_manager.available_nodes
        if not nodes:
            raise NodeUnavailable(
                "The music server is offline right now. I'm trying to reconnect, please retry shortly."
            )
        return nodes[0]

    @property
    def online(self) -> bool:
        return bool(self.client.node_manager.available_nodes)

    async def refresh_capabilities(self) -> Capabilities | None:
        try:
            info = await self.node().get_info()
        except (MusicError, *_NETWORK_ERRORS):
            log.warning("Could not read Lavalink /v4/info")
            return self.caps
        self.caps = Capabilities.from_info(dict(info))
        log.info(
            "Lavalink %s | sources: %s | plugins: %s",
            self.caps.version,
            ", ".join(sorted(self.caps.source_managers)) or "none",
            ", ".join(self.caps.plugins) or "none",
        )
        if self.caps.supports_dave is False:
            log.error(
                "Lavalink %s is too old. Discord now requires encrypted voice (DAVE), which needs "
                "Lavalink 4.2.0 or newer. Voice will NOT work until you update it "
                "(docker compose pull && docker compose up -d).",
                self.caps.version,
            )
        if "youtube" not in self.caps.source_managers:
            log.warning("YouTube is not enabled on Lavalink. Check that youtube-plugin loaded (see Lavalink logs).")
        return self.caps

    async def ensure_caps(self) -> Capabilities | None:
        """Capabilities if known. None means "couldn't ask": let Lavalink answer instead of guessing."""
        if self.caps is None:
            await self.refresh_capabilities()
        return self.caps

    # ------------------------------------------------------------------ resolving
    async def resolve(self, query: str, source: str = "youtube", requester: int = 0) -> Resolved:
        query = query.strip()
        if not query:
            raise MusicError("Tell me what to play: a song name or a link.")
        if len(query) > MAX_QUERY_LENGTH:
            raise MusicError("That's too long. Keep it under 500 characters.")
        if has_other_scheme(query):
            raise MusicError("Only http and https links are supported.")
        self.node()  # raises NodeUnavailable first if the music server is offline
        caps = await self.ensure_caps()

        if is_url(query):
            check = validate_url(query)
            if not check.ok:
                raise MusicError(check.reason)
            platform = detect_platform(query)
            if platform is Platform.HTTP:
                host_check = await ensure_public_host(query)
                if not host_check.ok:
                    raise MusicError(host_check.reason)
            if caps is not None:
                self._require_platform(platform, caps)
            if platform is Platform.DEEZER:
                return await self._resolve_deezer(query, requester)
            note = caps.status(platform)[1] if caps is not None else ""
            return await self._load(query, platform=platform, note=note)

        prefix, manager = SEARCH_PREFIXES.get(source, SEARCH_PREFIXES["youtube"])
        if caps is not None and manager not in caps.source_managers:
            label = source.replace("_", " ").title()
            raise SourceUnavailable(
                f"Searching {label} isn't enabled on this bot. Try the default YouTube search or paste a link."
            )
        resolved = await self._load(build_identifier(query, source), platform=None)
        resolved.note = f"{prefix} search"
        return resolved

    def _require_platform(self, platform: Platform, caps: Capabilities) -> None:
        playable, note = caps.status(platform)
        if not playable:
            raise SourceUnavailable(f"{platform.label} links aren't available on this bot: {note}.")

    async def _load(self, identifier: str, *, platform: Platform | None, note: str = "") -> Resolved:
        try:
            result = await self.client.get_tracks(identifier, node=self.node())
        except MusicError:
            raise
        except _NETWORK_ERRORS as exc:
            log.warning("Track load failed (%s): %s", identifier[:80], exc)
            raise NodeUnavailable("I couldn't reach the music server. Try again in a moment.") from exc

        if result.load_type is LoadType.ERROR:
            err = result.error
            log.warning("Lavalink load error for %s: %s", identifier[:80], err)
            raise MusicError(explain_load_error(err.message if err else "", err.cause if err else ""))
        if result.load_type is LoadType.EMPTY or not result.tracks:
            raise NothingFound("I couldn't find anything for that.")
        if result.load_type is LoadType.TRACK:
            return Resolved("track", [result.tracks[0]], platform=platform, note=note)
        if result.load_type is LoadType.PLAYLIST:
            limit = self.settings.max_playlist_import
            name = result.playlist_info.name or "Playlist"
            tracks = list(result.tracks)[:limit]
            extra = {"truncated": len(result.tracks) > limit, "total": len(result.tracks)}
            return Resolved("playlist", tracks, title=name, platform=platform, note=note, extra=extra)
        return Resolved("search", list(result.tracks)[:SEARCH_RESULT_LIMIT], platform=platform, note=note)

    async def _resolve_deezer(self, url: str, requester: int) -> Resolved:
        data = await deezer.fetch(self.session, url, self.settings.max_playlist_import)
        tracks: list[AudioTrack] = [
            LazySearchTrack.create(
                title=t.title,
                author=t.artist,
                duration_ms=t.duration_ms,
                uri=t.url,
                source_name="deezer",
                identifier=t.id,
                artwork_url=t.artwork,
                isrc=t.isrc,
                requester=requester,
            )
            for t in data.tracks
        ]
        kind = "track" if data.kind == "track" else "playlist"
        return Resolved(
            kind, tracks, title=data.name, platform=Platform.DEEZER, note="Deezer metadata, audio via YouTube"
        )

    # ------------------------------------------------------------------ autoplay
    async def autoplay_next(self, player: MusicPlayer) -> AudioTrack | None:
        seed = player._last_started or (player.history[-1] if player.history else None)
        if seed is None or seed.is_stream:
            return None
        candidates: list[AudioTrack] = []
        try:
            node = self.node()
            if seed.source_name == "youtube":
                vid = seed.identifier
                result = await self.client.get_tracks(
                    f"https://www.youtube.com/watch?v={vid}&list=RD{vid}", node=node
                )
                candidates = list(result.tracks)
            if not candidates:
                artist = clean_artist(seed.author)
                if artist:
                    result = await self.client.get_tracks(f"ytmsearch:{artist}", node=node)
                    candidates = list(result.tracks)
        except (MusicError, *_NETWORK_ERRORS):
            log.info("Autoplay lookup failed", exc_info=True)
            return None
        fresh = [
            t
            for t in candidates
            if t.identifier not in player.recent_ids and t.identifier != seed.identifier and not t.is_stream
        ]
        if not fresh:
            return None
        return random.choice(fresh[:10])
