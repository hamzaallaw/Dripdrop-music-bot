"""Glue between Discord and the player: joining voice, queueing, the now-playing panel,
queue persistence and 24/7 reconnection."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

import discord
import lavalink
from lavalink import AudioTrack

from commands.checks import humans_in, require_voice
from config import branding as b
from music import embeds
from music.errors import MusicError, NodeUnavailable
from music.player import MusicPlayer
from music.service import Resolved
from music.views import PlayerView
from music.voice import LavalinkVoiceClient, get_player
from utils.formatting import clean, format_duration, truncate

if TYPE_CHECKING:
    from bot.client import DripDropBot

log = logging.getLogger(__name__)

CONNECT_WAIT_SECONDS = 8.0
RESTORE_MAX_AGE_SECONDS = 6 * 3600
RECONNECT_RETRY_SECONDS = 60.0


class MusicController:
    def __init__(self, bot: DripDropBot):
        self.bot = bot
        self._tasks: set[asyncio.Task] = set()
        self._reconnect_after: dict[int, float] = {}

    # ------------------------------------------------------------------ voice
    async def ensure_player(self, interaction: discord.Interaction) -> MusicPlayer:
        """Make sure the bot is in the caller's voice channel and return its player."""
        guild = interaction.guild
        if guild is None:
            raise MusicError("This only works inside a server.")
        channel = require_voice(interaction)
        me = guild.me
        perms = channel.permissions_for(me)
        if not (perms.view_channel and perms.connect and perms.speak):
            raise MusicError(f"I need the View Channel, Connect and Speak permissions in {channel.mention}.")

        player = get_player(self.bot, guild.id)
        if player is not None and player.is_connected:
            current = guild.get_channel(player.channel_id) if player.channel_id else None
            if current is not None and current.id != channel.id:
                if player.always_on:
                    raise MusicError(f"I'm in 24/7 mode in {current.mention}. Join it to use me.")
                if humans_in(current):  # type: ignore[arg-type]
                    raise MusicError(f"I'm already playing in {current.mention}. Join it to add songs.")
                await self._move(guild, player, channel)
            player.text_channel_id = interaction.channel_id
            return player

        if channel.user_limit and len(channel.members) >= channel.user_limit and not perms.move_members:
            raise MusicError(f"{channel.mention} is full.")
        player = await self.connect(guild, channel, text_channel_id=interaction.channel_id)
        await self._restore_saved_queue(player)
        return player

    async def connect(
        self, guild: discord.Guild, channel: discord.VoiceChannel | discord.StageChannel, *, text_channel_id: int | None
    ) -> MusicPlayer:
        self.bot.music.node()  # NodeUnavailable if the music server is offline
        if guild.voice_client is not None:  # a stale connection
            await guild.voice_client.disconnect(force=True)
        try:
            await channel.connect(cls=LavalinkVoiceClient, self_deaf=True, timeout=20.0)
        except (TimeoutError, discord.ClientException, discord.HTTPException) as exc:
            log.warning("Voice connect failed in guild %s: %s", guild.id, exc)
            raise MusicError("I couldn't join that voice channel. Check my permissions and try again.") from exc
        player = get_player(self.bot, guild.id)
        if player is None or not await self._wait_until(lambda: player.is_connected):
            if guild.voice_client is not None:
                await guild.voice_client.disconnect(force=True)
            raise MusicError("Discord took too long to connect me to voice. Please try again.")
        await self._apply_settings(player)
        player.text_channel_id = text_channel_id
        return player

    async def _move(self, guild: discord.Guild, player: MusicPlayer, channel: discord.abc.Connectable) -> None:
        await guild.change_voice_state(channel=channel, self_deaf=True)
        if not await self._wait_until(lambda: player.channel_id == channel.id):
            raise MusicError("I couldn't move to your voice channel. Please try again.")

    @staticmethod
    async def _wait_until(predicate, timeout: float = CONNECT_WAIT_SECONDS) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            await asyncio.sleep(0.1)
        return bool(predicate())

    async def _apply_settings(self, player: MusicPlayer) -> None:
        row = await self.bot.db.get_settings(player.guild_id, default_volume=self.bot.settings.default_volume)
        player.volume = min(int(row["volume"]), self.bot.settings.max_volume)
        player.autoplay = bool(row["autoplay"])
        player.announce = bool(row["announce"])
        player.always_on = bool(row["always_on"])
        player.loop = row["loop_mode"] if row["loop_mode"] in (0, 1, 2) else 0

    async def leave(self, guild: discord.Guild, *, forget: bool = True) -> None:
        player = get_player(self.bot, guild.id)
        if player is not None:
            await self.close_panel(player, "Left the voice channel. See you next time!")
        vc = guild.voice_client
        try:
            if vc is not None:
                await vc.disconnect(force=True)
            elif player is not None:
                await self.bot.lavalink.player_manager.destroy(guild.id)
        except (discord.HTTPException, lavalink.ClientError):
            log.debug("Error while leaving guild %s", guild.id, exc_info=True)
        if forget:
            await self.bot.db.clear_queue_state(guild.id)

    async def stop(self, guild: discord.Guild, player: MusicPlayer) -> None:
        """Stop, clear the queue, and leave unless 24/7 mode is on."""
        player.clear()
        player.history.clear()
        player.loop = player.LOOP_NONE
        await player.stop()
        await self.bot.db.clear_queue_state(guild.id)
        if player.always_on:
            await self.close_panel(player, "Stopped. I'm staying in the channel (24/7 mode).")
        else:
            await self.leave(guild)

    # ------------------------------------------------------------------ queueing
    async def enqueue(
        self, interaction: discord.Interaction, resolved: Resolved, *, play_next: bool = False
    ) -> discord.Embed:
        tracks = resolved.tracks[:1] if resolved.kind == "search" else resolved.tracks
        title = resolved.title
        return await self.enqueue_tracks(
            interaction, tracks, title=title, play_next=play_next, note=resolved.note, extra=resolved.extra,
            as_playlist=resolved.kind == "playlist",
        )

    async def enqueue_tracks(
        self,
        interaction: discord.Interaction,
        tracks: list[AudioTrack],
        *,
        title: str = "",
        play_next: bool = False,
        note: str = "",
        extra: dict | None = None,
        as_playlist: bool | None = None,
    ) -> discord.Embed:
        if not tracks:
            raise MusicError("There's nothing to add.")
        player = await self.ensure_player(interaction)
        room = self.bot.settings.max_queue_size - len(player.queue)
        if room <= 0:
            raise MusicError(f"The queue is full ({self.bot.settings.max_queue_size} tracks). Use `/clear` or `/remove`.")
        tracks = tracks[:room]
        uid = interaction.user.id
        was_idle = player.current is None
        for offset, track in enumerate(tracks):
            player.add(track, requester=uid, index=offset if play_next else None)
        first_position = 1 if play_next else len(player.queue) - len(tracks) + 1

        if was_idle:
            await self._start(player)
        self.persist(player)

        restored = getattr(player, "restored_count", 0)
        player.restored_count = 0  # type: ignore[attr-defined]
        if as_playlist is None:
            as_playlist = len(tracks) > 1
        if as_playlist:
            total = sum(t.duration for t in tracks if not t.is_stream)
            embed = embeds.added_playlist(title or "Tracks", len(tracks), total, extra, note)
        elif was_idle and not restored:
            embed = embeds.success(f"Playing {_short(tracks[0])}")
        else:
            position = None if was_idle else first_position
            embed = embeds.added_track(tracks[0], position, self.bot.user.id, note)  # type: ignore[union-attr]
        if restored:
            embed.set_footer(text=f"{b.NAME} · Restored {restored} tracks from your last session")
        return embed

    async def _start(self, player: MusicPlayer) -> None:
        try:
            await player.play(volume=player.volume)
        except lavalink.RequestError as exc:
            log.warning("Could not start playback in guild %s: %s", player.guild_id, exc)
            raise NodeUnavailable("I couldn't start playback. The music server may be restarting.") from exc

    # ------------------------------------------------------------------ persistence
    def persist(self, player: MusicPlayer) -> None:
        """Save the queue in the background. Cheap, and never blocks a command."""
        guild_id = player.guild_id
        if player.current is None and not player.queue:
            coro = self.bot.db.clear_queue_state(guild_id)
        else:
            coro = self.bot.db.save_queue(guild_id, player.snapshot())
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._task_done)

    def _task_done(self, task: asyncio.Task) -> None:
        self._tasks.discard(task)
        if not task.cancelled() and task.exception() is not None:
            log.warning("Queue save failed", exc_info=task.exception())

    async def _restore_saved_queue(self, player: MusicPlayer) -> None:
        state = await self.bot.db.load_queue(player.guild_id)
        if not state or time.time() - int(state.get("saved_at", 0)) > RESTORE_MAX_AGE_SECONDS:
            return
        resume, _ = player.restore(state)
        if resume is not None:
            player.queue.insert(0, resume)
        count = len(player.queue)
        if count:
            player.restored_count = count  # type: ignore[attr-defined]
            log.info("Restored %d tracks for guild %s", count, player.guild_id)

    async def restore_always_on(self) -> None:
        """Reconnect 24/7 guilds that lost their voice connection (also runs at startup)."""
        for row in await self.bot.db.always_on_guilds():
            guild_id = row["guild_id"]
            if time.monotonic() < self._reconnect_after.get(guild_id, 0):
                continue
            guild = self.bot.get_guild(guild_id)
            player = get_player(self.bot, guild_id)
            if guild is None or (player is not None and player.is_connected):
                continue
            channel = guild.get_channel(row["voice_channel_id"])
            if not isinstance(channel, (discord.VoiceChannel, discord.StageChannel)):
                continue
            try:
                player = await self.connect(guild, channel, text_channel_id=row.get("text_channel_id"))
                player.always_on = True
                await self._restore_saved_queue(player)
                player.restored_count = 0  # type: ignore[attr-defined]
                if player.queue and player.current is None:
                    await self._start(player)
                log.info("24/7: reconnected to %s in guild %s", channel.name, guild_id)
            except (MusicError, discord.HTTPException) as exc:
                self._reconnect_after[guild_id] = time.monotonic() + RECONNECT_RETRY_SECONDS
                log.warning("24/7 reconnect failed for guild %s: %s", guild_id, exc)

    # ------------------------------------------------------------------ now-playing panel
    def _text_channel(self, player: MusicPlayer) -> discord.abc.Messageable | None:
        channel = self.bot.get_channel(player.text_channel_id) if player.text_channel_id else None
        guild = self.bot.get_guild(player.guild_id)
        if channel is None or guild is None or not hasattr(channel, "send"):
            return None
        perms = channel.permissions_for(guild.me)  # type: ignore[union-attr]
        if not (perms.view_channel and perms.send_messages and perms.embed_links):
            return None
        return channel  # type: ignore[return-value]

    async def post_panel(self, player: MusicPlayer, track: AudioTrack) -> None:
        if not player.announce:
            return
        channel = self._text_channel(player)
        if channel is None:
            return
        embed = embeds.now_playing(player, self.bot.user.id, track)  # type: ignore[union-attr]
        view = PlayerView(self.bot, player)
        if player.panel_message_id and getattr(channel, "last_message_id", None) == player.panel_message_id:
            try:  # our panel is still the newest message: update it in place
                await channel.get_partial_message(player.panel_message_id).edit(embed=embed, view=view)  # type: ignore[attr-defined]
                return
            except discord.HTTPException:
                player.panel_message_id = None
        await self._delete_panel(player)
        try:
            message = await channel.send(embed=embed, view=view)
        except discord.HTTPException:
            log.warning("Could not post the now-playing panel in guild %s", player.guild_id)
            return
        player.panel_channel_id = message.channel.id
        player.panel_message_id = message.id

    async def refresh_panel(self, player: MusicPlayer) -> None:
        if not player.panel_message_id or player.current is None:
            return
        channel = self.bot.get_channel(player.panel_channel_id or 0)
        if channel is None:
            player.panel_message_id = None
            return
        try:
            await channel.get_partial_message(player.panel_message_id).edit(  # type: ignore[attr-defined]
                embed=embeds.now_playing(player, self.bot.user.id), view=PlayerView(self.bot, player)  # type: ignore[union-attr]
            )
        except (discord.NotFound, discord.Forbidden):
            player.panel_message_id = None
        except discord.HTTPException:
            log.debug("Panel refresh failed", exc_info=True)

    async def close_panel(self, player: MusicPlayer, text: str = "Queue finished.") -> None:
        if not player.panel_message_id:
            return
        channel = self.bot.get_channel(player.panel_channel_id or 0)
        message_id, player.panel_message_id = player.panel_message_id, None
        if channel is None:
            return
        try:
            await channel.get_partial_message(message_id).edit(embed=embeds.idle(text), view=None)  # type: ignore[attr-defined]
        except discord.HTTPException:
            pass

    async def _delete_panel(self, player: MusicPlayer) -> None:
        if not player.panel_message_id:
            return
        channel = self.bot.get_channel(player.panel_channel_id or 0)
        message_id, player.panel_message_id = player.panel_message_id, None
        if channel is None:
            return
        try:
            await channel.get_partial_message(message_id).delete()  # type: ignore[attr-defined]
        except discord.HTTPException:
            pass


def _short(track: AudioTrack) -> str:
    """'**Title** `3:20`' for the success message."""
    return f"**{truncate(clean(track.title), 100)}** `{format_duration(track.duration, is_stream=track.is_stream)}`"
