"""Errors whose message is safe to show directly to Discord users."""

from __future__ import annotations

from discord import app_commands


class MusicError(app_commands.AppCommandError):
    """A problem the user can understand. The message is shown as-is."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message


class SourceUnavailable(MusicError):
    """The requested platform is not enabled on the Lavalink node."""


class NodeUnavailable(MusicError):
    """The Lavalink server cannot be reached."""


class NothingFound(MusicError):
    """A search or link returned no playable tracks."""
