"""Interactive Discord components: player buttons, queue pages, search menu, lyrics pages."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from lavalink import AudioTrack

from commands.checks import control_player
from commands.errors import send_error
from config import branding as b
from music import embeds
from music.errors import MusicError
from music.player import MusicPlayer
from music.voice import get_player
from services.lyrics import Lyrics, paginate_text
from utils.formatting import clean, format_duration, truncate

if TYPE_CHECKING:
    from bot.client import DripDropBot

log = logging.getLogger(__name__)
VOLUME_STEP = 10


class PlayerView(discord.ui.View):
    """The control panel under the now-playing message.

    Buttons use fixed custom_ids, so the same class registered once with the bot keeps
    old panels working after a restart.
    """

    def __init__(self, bot: DripDropBot, player: MusicPlayer | None = None):
        super().__init__(timeout=None)
        self.bot = bot
        if player is not None:
            self.play_pause.emoji = b.ICON_PLAY if player.paused else b.ICON_PAUSE
            self.loop.emoji = b.ICON_LOOP_ONE if player.loop == player.LOOP_SINGLE else b.ICON_LOOP
            self.loop.style = (
                discord.ButtonStyle.secondary if player.loop == player.LOOP_NONE else discord.ButtonStyle.success
            )

    async def _guard(self, interaction: discord.Interaction, *, dj: bool = True) -> MusicPlayer | None:
        try:
            return await control_player(self.bot, interaction, dj=dj)
        except MusicError as exc:
            await send_error(interaction, exc.message)
            return None

    async def _refresh(self, interaction: discord.Interaction, player: MusicPlayer) -> None:
        self.bot.controller.persist(player)
        await interaction.response.edit_message(
            embed=embeds.now_playing(player, self.bot.user.id), view=PlayerView(self.bot, player)  # type: ignore[union-attr]
        )

    @discord.ui.button(emoji=b.ICON_PAUSE, style=discord.ButtonStyle.primary, custom_id="dd:playpause", row=0)
    async def play_pause(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction)
        if player is None:
            return
        await player.set_pause(not player.paused)
        await self._refresh(interaction, player)

    @discord.ui.button(emoji=b.ICON_SKIP, style=discord.ButtonStyle.secondary, custom_id="dd:skip", row=0)
    async def skip(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction)
        if player is None:
            return
        if player.current is None:
            await send_error(interaction, "Nothing is playing right now.")
            return
        await interaction.response.defer()  # the track-start event refreshes the panel
        await player.skip_track()

    @discord.ui.button(emoji=b.ICON_STOP, style=discord.ButtonStyle.danger, custom_id="dd:stop", row=0)
    async def stop(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction)
        if player is None or interaction.guild is None:
            return
        await interaction.response.edit_message(
            embed=embeds.idle("Stopped. Use `/play` to start again."), view=None
        )
        await self.bot.controller.stop(interaction.guild, player)

    @discord.ui.button(emoji=b.ICON_LOOP, style=discord.ButtonStyle.secondary, custom_id="dd:loop", row=0)
    async def loop(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction)
        if player is None:
            return
        player.loop = (player.loop + 1) % 3  # off -> track -> queue -> off
        await self._refresh(interaction, player)

    @discord.ui.button(emoji=b.ICON_QUEUE, style=discord.ButtonStyle.secondary, custom_id="dd:queue", row=0)
    async def queue(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction, dj=False)
        if player is None:
            return
        view = QueueView(self.bot, interaction.guild_id or 0, interaction.user.id)
        await interaction.response.send_message(
            embed=embeds.queue_page(player, self.bot.user.id), view=view, ephemeral=True  # type: ignore[union-attr]
        )

    @discord.ui.button(emoji=b.ICON_PREVIOUS, style=discord.ButtonStyle.secondary, custom_id="dd:prev", row=1)
    async def previous(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction)
        if player is None:
            return
        if not player.history:
            await send_error(interaction, "There's no previous track.")
            return
        await interaction.response.defer()
        await player.play_previous()

    @discord.ui.button(emoji=b.ICON_SHUFFLE, style=discord.ButtonStyle.secondary, custom_id="dd:shuffle", row=1)
    async def shuffle(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        player = await self._guard(interaction)
        if player is None:
            return
        if len(player.queue) < 2:
            await send_error(interaction, "Add at least two songs to the queue to shuffle.")
            return
        player.shuffle_queue()
        await self._refresh(interaction, player)

    @discord.ui.button(emoji="🔉", style=discord.ButtonStyle.secondary, custom_id="dd:voldown", row=1)
    async def volume_down(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._change_volume(interaction, -VOLUME_STEP)

    @discord.ui.button(emoji="🔊", style=discord.ButtonStyle.secondary, custom_id="dd:volup", row=1)
    async def volume_up(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self._change_volume(interaction, VOLUME_STEP)

    async def _change_volume(self, interaction: discord.Interaction, delta: int) -> None:
        player = await self._guard(interaction)
        if player is None or interaction.guild is None:
            return
        level = max(0, min(self.bot.settings.max_volume, player.volume + delta))
        await player.set_volume(level)
        await self.bot.db.update_settings(interaction.guild.id, volume=level)
        await self._refresh(interaction, player)


class _OwnerView(discord.ui.View):
    """A view only the person who opened it may use."""

    def __init__(self, owner_id: int, timeout: float):
        super().__init__(timeout=timeout)
        self.owner_id = owner_id
        self.interaction: discord.Interaction | None = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await send_error(interaction, "Only the person who ran the command can use these buttons.")
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            item.disabled = True  # type: ignore[attr-defined]
        if self.interaction is not None:
            try:
                await self.interaction.edit_original_response(view=self)
            except discord.HTTPException:
                pass


class QueueView(_OwnerView):
    def __init__(self, bot: DripDropBot, guild_id: int, owner_id: int, page: int = 1):
        super().__init__(owner_id, timeout=120)
        self.bot = bot
        self.guild_id = guild_id
        self.page = page

    def _render(self) -> discord.Embed:
        player = get_player(self.bot, self.guild_id)
        if player is None:
            return embeds.idle()
        self.page = min(max(self.page, 1), embeds.queue_pages(player, self.bot.user.id))  # type: ignore[union-attr]
        return embeds.queue_page(player, self.bot.user.id, self.page)  # type: ignore[union-attr]

    @discord.ui.button(emoji="◀️", style=discord.ButtonStyle.secondary)
    async def prev_page(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page -= 1
        await interaction.response.edit_message(embed=self._render(), view=self)

    @discord.ui.button(emoji="▶️", style=discord.ButtonStyle.secondary)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page += 1
        await interaction.response.edit_message(embed=self._render(), view=self)


class _TrackSelect(discord.ui.Select):
    def __init__(self, tracks: list[AudioTrack]):
        options = [
            discord.SelectOption(
                label=f"{i}. {truncate(clean(t.title), 90)}",
                description=truncate(f"{clean(t.author)} · {format_duration(t.duration, is_stream=t.is_stream)}", 100),
                value=str(i - 1),
            )
            for i, t in enumerate(tracks, start=1)
        ]
        super().__init__(
            placeholder="Choose what to play…", min_values=1, max_values=min(len(options), 5), options=options
        )
        self.tracks = tracks

    async def callback(self, interaction: discord.Interaction) -> None:
        view: SearchView = self.view  # type: ignore[assignment]
        chosen = [self.tracks[int(v)] for v in self.values]
        await interaction.response.defer()
        try:
            embed = await view.bot.controller.enqueue_tracks(
                interaction, chosen, title="Selected tracks", play_next=view.play_next
            )
        except MusicError as exc:
            await interaction.followup.send(embed=embeds.error(exc.message), ephemeral=True)
            return
        for item in view.children:
            item.disabled = True  # type: ignore[attr-defined]
        view.stop()
        await interaction.edit_original_response(embed=embed, view=view)


class SearchView(_OwnerView):
    def __init__(self, bot: DripDropBot, owner_id: int, tracks: list[AudioTrack], play_next: bool = False):
        super().__init__(owner_id, timeout=60)
        self.bot = bot
        self.play_next = play_next
        self.add_item(_TrackSelect(tracks))


class LyricsView(_OwnerView):
    def __init__(self, lyrics: Lyrics, owner_id: int):
        super().__init__(owner_id, timeout=300)
        self.lyrics = lyrics
        self.pages = paginate_text(lyrics.text) if lyrics.text else [""]
        self.page = 1
        if len(self.pages) == 1:
            self.clear_items()

    def render(self) -> discord.Embed:
        return embeds.lyrics_page(self.lyrics, self.pages[self.page - 1], self.page, len(self.pages))

    @discord.ui.button(emoji="◀️", style=discord.ButtonStyle.secondary)
    async def prev_page(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page = max(1, self.page - 1)
        await interaction.response.edit_message(embed=self.render(), view=self)

    @discord.ui.button(emoji="▶️", style=discord.ButtonStyle.secondary)
    async def next_page(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        self.page = min(len(self.pages), self.page + 1)
        await interaction.response.edit_message(embed=self.render(), view=self)
