"""Turn tracks into plain dicts (for SQLite) and back."""

from __future__ import annotations

from typing import Any

from lavalink import AudioTrack, InvalidTrack

from music.lazy import LazySearchTrack


def serialize_track(track: AudioTrack) -> dict[str, Any]:
    return {"raw": track.raw, "requester": track.requester}


def deserialize_track(data: dict[str, Any]) -> AudioTrack | None:
    """Rebuild a track. Returns None if the stored data is damaged."""
    try:
        raw = data["raw"]
        if not isinstance(raw, dict):
            return None
        requester = int(data.get("requester", 0))
        if LazySearchTrack.is_lazy(raw) and not raw.get("encoded"):
            return LazySearchTrack(raw, requester)
        return AudioTrack(raw, requester)
    except (KeyError, TypeError, ValueError, AttributeError, InvalidTrack):
        return None


def serialize_many(tracks: list[AudioTrack], limit: int = 500) -> list[dict[str, Any]]:
    return [serialize_track(t) for t in tracks[:limit]]


def deserialize_many(items: list[dict[str, Any]]) -> list[AudioTrack]:
    out = []
    for item in items:
        track = deserialize_track(item) if isinstance(item, dict) else None
        if track is not None:
            out.append(track)
    return out
