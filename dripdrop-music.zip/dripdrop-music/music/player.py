"""Per-server player: Lavalink.py's DefaultPlayer plus history, autoplay and persistence."""

from __future__ import annotations

import random
import time
from collections import deque
from typing import Any

import lavalink
from lavalink import AudioTrack, DefaultPlayer, EndReason

from music.tracks import deserialize_many, deserialize_track, serialize_many, serialize_track

HISTORY_LIMIT = 50
SNAPSHOT_VERSION = 1


class MusicPlayer(DefaultPlayer):
    def __init__(self, guild_id: int, node: lavalink.Node):
        super().__init__(guild_id, node)
        self.history: list[AudioTrack] = []
        self.recent_ids: deque[str] = deque(maxlen=HISTORY_LIMIT)
        self.autoplay: bool = False
        self.always_on: bool = False
        self.announce: bool = True
        self.text_channel_id: int | None = None
        self.panel_channel_id: int | None = None
        self.panel_message_id: int | None = None
        self.idle_since: float | None = None
        self._history_skips = 0
        self._last_started: AudioTrack | None = None

    # ------------------------------------------------------------------ history
    def record_finished(self, track: AudioTrack | None, reason: EndReason) -> None:
        """Called from TrackEndEvent. Keeps the stack used by /previous."""
        if track is None or reason not in (EndReason.FINISHED, EndReason.REPLACED):
            return
        if reason is EndReason.REPLACED and self._history_skips > 0:
            self._history_skips -= 1
            return
        if self.loop == self.LOOP_SINGLE and reason is EndReason.FINISHED:
            return  # the same track is about to repeat
        self.history.append(track)
        del self.history[:-HISTORY_LIMIT]

    def remember_started(self, track: AudioTrack) -> None:
        self._last_started = track
        self.recent_ids.append(track.identifier)
        self.idle_since = None

    async def play_previous(self) -> AudioTrack | None:
        """Go back one track. Returns it, or None if there is no history."""
        if not self.history:
            return None
        previous = self.history.pop()
        if self.current is not None and self.loop == self.LOOP_NONE:
            self.queue.insert(0, self.current)  # so "skip" returns to where we were
        self._history_skips += 1
        await self.play(track=previous)
        return previous

    async def skip_track(self) -> None:
        """Skip to the next track. Skipping while looping one track must still move on."""
        if self.loop == self.LOOP_SINGLE:
            self.loop = self.LOOP_NONE
            try:
                await self.skip()
            finally:
                self.loop = self.LOOP_SINGLE
        else:
            await self.skip()

    # ------------------------------------------------------------------ queue ops
    def shuffle_queue(self) -> None:
        random.shuffle(self.queue)

    def move(self, source: int, target: int) -> AudioTrack:
        """1-based positions. Raises IndexError when out of range."""
        if not (1 <= source <= len(self.queue) and 1 <= target <= len(self.queue)):
            raise IndexError("position out of range")
        track = self.queue.pop(source - 1)
        self.queue.insert(target - 1, track)
        return track

    def remove(self, position: int) -> AudioTrack:
        if not 1 <= position <= len(self.queue):
            raise IndexError("position out of range")
        return self.queue.pop(position - 1)

    def clear(self) -> int:
        removed = len(self.queue)
        self.queue.clear()
        return removed

    def total_queue_ms(self) -> int:
        return sum(t.duration for t in self.queue if not t.is_stream)

    # ------------------------------------------------------------------ persistence
    def snapshot(self) -> dict[str, Any]:
        return {
            "v": SNAPSHOT_VERSION,
            "saved_at": int(time.time()),
            "current": serialize_track(self.current) if self.current else None,
            "position": self.position if self.current else 0,
            "queue": serialize_many(self.queue),
            "loop": self.loop,
            "volume": self.volume,
        }

    def restore(self, state: dict[str, Any]) -> tuple[AudioTrack | None, int]:
        """Load a snapshot into this player (does not start playback).

        Returns (track to resume, position in ms). The resumed track is NOT in the queue.
        """
        if not isinstance(state, dict) or state.get("v") != SNAPSHOT_VERSION:
            return None, 0
        self.queue = deserialize_many(state.get("queue", []))
        loop = state.get("loop", 0)
        self.loop = loop if loop in (0, 1, 2) else 0
        resume = deserialize_track(state["current"]) if state.get("current") else None
        position = state.get("position", 0)
        position = position if isinstance(position, int) and position > 0 else 0
        if resume is not None and (not resume.is_seekable or resume.is_stream):
            position = 0
        return resume, position
