"""Every embed the bot sends. One place, one consistent dark/violet look."""

from __future__ import annotations

from typing import Any

import discord
from lavalink import AudioTrack

from config import branding as b
from music.capabilities import Capabilities
from music.player import MusicPlayer
from services.lyrics import Lyrics
from utils.formatting import clean, format_duration, progress_bar, truncate
from utils.urls import Platform, is_url

QUEUE_PAGE_SIZE = 10


def base(
    title: str | None = None,
    description: str | None = None,
    *,
    color: int = b.COLOR_ACCENT,
) -> discord.Embed:
    embed = discord.Embed(title=title, description=description, color=color)
    embed.set_footer(text=b.FOOTER)
    return embed


def success(text: str) -> discord.Embed:
    return base(description=f"{b.ICON_OK} {text}", color=b.COLOR_SUCCESS)


def error(text: str) -> discord.Embed:
    return base(description=f"{b.ICON_ERROR} {text}", color=b.COLOR_ERROR)


def warning(text: str) -> discord.Embed:
    return base(description=f"{b.ICON_WARN} {text}", color=b.COLOR_WARNING)


def info(text: str, title: str | None = None) -> discord.Embed:
    return base(title=title, description=text, color=b.COLOR_NEUTRAL)


def requester_text(track: AudioTrack, bot_id: int) -> str:
    requester = getattr(track, "requester", 0)
    if requester == bot_id:
        return f"{b.ICON_AUTOPLAY} Autoplay"
    return f"<@{requester}>" if requester else "Unknown"


def _title(track: AudioTrack, limit: int = 256) -> str:
    return truncate(clean(track.title), limit)


def _link(track: AudioTrack) -> str | None:
    return track.uri if track.uri and is_url(track.uri) else None


def loop_text(player: MusicPlayer) -> str:
    return {
        player.LOOP_NONE: "Off",
        player.LOOP_SINGLE: f"{b.ICON_LOOP_ONE} Track",
        player.LOOP_QUEUE: f"{b.ICON_LOOP} Queue",
    }.get(player.loop, "Off")


def idle(text: str = "Nothing is playing. Use `/play` to start the party.") -> discord.Embed:
    return base(title=f"{b.NAME}", description=text, color=b.COLOR_NEUTRAL)


def now_playing(player: MusicPlayer, bot_id: int, track: AudioTrack | None = None) -> discord.Embed:
    track = track or player.current
    if track is None:
        return idle()
    paused = player.paused
    state = f"{b.ICON_PAUSE} Paused" if paused else f"{b.ICON_PLAY} Now playing"
    position = player.position if player.current is track else 0

    embed = discord.Embed(title=_title(track), url=_link(track), color=b.COLOR_ACCENT)
    embed.set_author(name=state)
    bar = progress_bar(position, track.duration, is_stream=track.is_stream)
    if track.is_stream:
        timeline = bar
    else:
        timeline = f"`{format_duration(position)}` {bar} `{format_duration(track.duration)}`"
    embed.description = f"**{truncate(clean(track.author), 200)}**\n\n{timeline}"
    embed.add_field(name="Requested by", value=requester_text(track, bot_id), inline=True)
    embed.add_field(name=f"{b.ICON_VOLUME} Volume", value=f"{player.volume}%", inline=True)
    extras = [f"Loop: {loop_text(player)}"]
    if player.autoplay:
        extras.append(f"{b.ICON_AUTOPLAY} Autoplay on")
    embed.add_field(name="Mode", value="\n".join(extras), inline=True)
    if track.artwork_url:
        embed.set_thumbnail(url=track.artwork_url)
    if player.queue:
        embed.set_footer(text=f"{b.NAME} · {len(player.queue)} up next")
    else:
        embed.set_footer(text=b.FOOTER)
    return embed


def added_track(track: AudioTrack, position: int | None, bot_id: int, note: str = "") -> discord.Embed:
    where = "Playing next" if position == 1 else f"Position {position}" if position else "Starting now"
    embed = base(title=f"{b.ICON_OK} Added to queue", description=f"**{_title(track, 200)}**\n{truncate(clean(track.author), 200)}")
    embed.url = _link(track)
    embed.add_field(name="Length", value=format_duration(track.duration, is_stream=track.is_stream), inline=True)
    embed.add_field(name="Queue", value=where, inline=True)
    if note:
        embed.set_footer(text=f"{b.NAME} · {note}")
    if track.artwork_url:
        embed.set_thumbnail(url=track.artwork_url)
    return embed


def added_playlist(name: str, count: int, total_ms: int, extra: dict[str, Any] | None = None, note: str = "") -> discord.Embed:
    text = f"**{truncate(clean(name), 200)}**\n{count} tracks · {format_duration(total_ms)}"
    if extra and extra.get("truncated"):
        text += f"\n{b.ICON_WARN} Only the first {count} of {extra.get('total')} tracks were added."
    embed = base(title=f"{b.ICON_OK} Playlist added", description=text)
    if note:
        embed.set_footer(text=f"{b.NAME} · {note}")
    return embed


def queue_pages(player: MusicPlayer, bot_id: int) -> int:
    return max(1, -(-len(player.queue) // QUEUE_PAGE_SIZE))


def queue_page(player: MusicPlayer, bot_id: int, page: int = 1) -> discord.Embed:
    pages = queue_pages(player, bot_id)
    page = min(max(page, 1), pages)
    lines: list[str] = []
    if player.current:
        cur = player.current
        lines.append(
            f"**{b.ICON_PLAY} Now playing**\n{_title(cur, 100)} · {truncate(clean(cur.author), 40)} "
            f"`{format_duration(cur.duration, is_stream=cur.is_stream)}`\n"
        )
    if player.queue:
        lines.append("**Up next**")
        start = (page - 1) * QUEUE_PAGE_SIZE
        for i, track in enumerate(player.queue[start : start + QUEUE_PAGE_SIZE], start=start + 1):
            lines.append(
                f"`{i}.` {_title(track, 70)} · {truncate(clean(track.author), 30)} "
                f"`{format_duration(track.duration, is_stream=track.is_stream)}`"
            )
    else:
        lines.append("The queue is empty. Add songs with `/play`.")
    embed = base(title=f"{b.ICON_QUEUE} Queue", description=truncate("\n".join(lines), 4000), color=b.COLOR_ACCENT)
    total = player.total_queue_ms()
    embed.set_footer(
        text=f"{b.NAME} · Page {page}/{pages} · {len(player.queue)} tracks · {format_duration(total)} · Loop: {loop_text(player)}"
    )
    return embed


def search_results(query: str, tracks: list[AudioTrack]) -> discord.Embed:
    lines = [
        f"`{i}.` {_title(t, 80)} · {truncate(clean(t.author), 30)} `{format_duration(t.duration, is_stream=t.is_stream)}`"
        for i, t in enumerate(tracks, start=1)
    ]
    return base(
        title=f"{b.ICON_SEARCH} Results for “{truncate(clean(query), 80)}”",
        description="\n".join(lines) + "\n\nPick one or more below.",
    )


def lyrics_page(lyrics: Lyrics, text: str, page: int, pages: int) -> discord.Embed:
    embed = base(
        title=f"{b.ICON_LYRICS} {truncate(clean(lyrics.title or 'Lyrics'), 200)}",
        description=text or "*Instrumental*",
    )
    if lyrics.artist:
        embed.set_author(name=lyrics.artist)
    embed.set_footer(text=f"{b.NAME} · Lyrics from LRCLIB · Page {page}/{pages}")
    return embed


def settings_embed(row: dict[str, Any], guild: discord.Guild) -> discord.Embed:
    dj = f"<@&{row['dj_role_id']}>" if row.get("dj_role_id") else "Everyone (no DJ role set)"
    voice = f"<#{row['voice_channel_id']}>" if row.get("voice_channel_id") and row.get("always_on") else "—"
    embed = base(title=f"⚙️ Settings for {truncate(clean(guild.name), 80)}", color=b.COLOR_NEUTRAL)
    embed.add_field(name="Default volume", value=f"{row['volume']}%", inline=True)
    embed.add_field(name="DJ role", value=dj, inline=True)
    embed.add_field(name="Announce songs", value="On" if row["announce"] else "Off", inline=True)
    embed.add_field(name="24/7 mode", value=f"On in {voice}" if row["always_on"] else "Off", inline=True)
    embed.add_field(name="Autoplay", value="On" if row["autoplay"] else "Off", inline=True)
    embed.add_field(name="Loop default", value={0: "Off", 1: "Track", 2: "Queue"}.get(row["loop_mode"], "Off"), inline=True)
    return embed


_HELP_SECTIONS: tuple[tuple[str, tuple[tuple[str, str], ...]], ...] = (
    (
        f"{b.ICON_PLAY} Playback",
        (
            ("/play", "Play a song or link (add `next` to play it next)"),
            ("/pause · /resume", "Pause or continue"),
            ("/skip · /previous", "Next or previous track"),
            ("/stop", "Stop, clear the queue and leave"),
            ("/seek", "Jump to a time, like `1:30`"),
            ("/volume", "Show or set the volume"),
        ),
    ),
    (
        f"{b.ICON_QUEUE} Queue",
        (
            ("/queue", "Show the queue"),
            ("/clear · /shuffle", "Empty or mix up the queue"),
            ("/remove · /move", "Remove or reorder a track"),
            ("/loop · /autoplay", "Repeat a track or queue, or keep similar songs coming"),
        ),
    ),
    (
        f"{b.ICON_SEARCH} Discover",
        (
            ("/nowplaying", "Show the current song"),
            ("/search", "Search and pick from results"),
            ("/lyrics", "Lyrics for the current song or a search"),
            ("/playlist", "Import links, save and load your own playlists"),
        ),
    ),
    (
        "⚙️ Admin (Manage Server)",
        (
            ("/247", "Stay in your voice channel all the time"),
            ("/settings", "DJ role, default volume, announcements"),
        ),
    ),
)

_HELP_PLATFORMS = (
    Platform.YOUTUBE,
    Platform.YOUTUBE_MUSIC,
    Platform.SPOTIFY,
    Platform.SOUNDCLOUD,
    Platform.APPLE_MUSIC,
    Platform.DEEZER,
    Platform.BANDCAMP,
    Platform.TWITCH,
    Platform.VIMEO,
    Platform.HTTP,
)


def help_embed(caps: Capabilities | None, node_online: bool) -> discord.Embed:
    embed = base(
        title=f"🎧 {b.NAME}",
        description="Slash commands only. Type `/` to see them. There is no text prefix to set.",
    )
    for name, commands_ in _HELP_SECTIONS:
        embed.add_field(
            name=name, value="\n".join(f"`{cmd}` {desc}" for cmd, desc in commands_), inline=False
        )
    if not node_online:
        status = f"{b.ICON_ERROR} The music server is offline right now."
    elif caps is None:
        status = f"{b.ICON_WARN} Couldn't read which platforms are enabled."
    else:
        rows = []
        for platform in _HELP_PLATFORMS:
            ok, note = caps.status(platform)
            rows.append(f"{b.ICON_OK if ok else b.ICON_ERROR} {platform.label}" + ("" if ok and note == "native" else f" ({note})"))
        status = "\n".join(rows) + f"\n\nLavalink {caps.version}"
    embed.add_field(name="Platforms on this bot", value=truncate(status, 1000), inline=False)
    return embed
