"""Tracks whose audio is looked up at play time.

Deezer links give us metadata (title, artist, length) but no audio we are allowed to
stream. So we keep the metadata now and, when the track is about to play, find the same
song on a playable provider (YouTube Music, then YouTube). Importing a 100-track playlist
therefore costs one API call, not 100 searches.
"""

from __future__ import annotations

from typing import Any

import lavalink
from lavalink import AudioTrack, DeferredAudioTrack

LAZY_MARKER = "dripdrop_lazy"
MATCH_TOLERANCE_MS = 15_000


def pick_best_match(candidates: list[AudioTrack], expected_ms: int) -> AudioTrack | None:
    """Prefer the candidate closest in length (within tolerance), else the first result."""
    if not candidates:
        return None
    if expected_ms > 0:
        scored = sorted(
            (c for c in candidates[:5] if not c.is_stream),
            key=lambda c: abs(c.duration - expected_ms),
        )
        if scored and abs(scored[0].duration - expected_ms) <= MATCH_TOLERANCE_MS:
            return scored[0]
    return candidates[0]


class LazySearchTrack(DeferredAudioTrack):
    __slots__ = ()

    @classmethod
    def create(
        cls,
        *,
        title: str,
        author: str,
        duration_ms: int,
        uri: str,
        source_name: str,
        identifier: str,
        artwork_url: str | None = None,
        isrc: str | None = None,
        requester: int = 0,
    ) -> LazySearchTrack:
        data: dict[str, Any] = {
            "encoded": None,
            "info": {
                "identifier": identifier,
                "isSeekable": True,
                "author": author,
                "length": duration_ms,
                "isStream": False,
                "position": 0,
                "title": title,
                "uri": uri,
                "artworkUrl": artwork_url,
                "isrc": isrc,
                "sourceName": source_name,
            },
            "pluginInfo": {LAZY_MARKER: True},
        }
        return cls(data, requester)

    @staticmethod
    def is_lazy(raw: Any) -> bool:
        if not isinstance(raw, dict):
            return False
        plugin_info = raw.get("pluginInfo")
        return isinstance(plugin_info, dict) and bool(plugin_info.get(LAZY_MARKER))

    async def load(self, client: lavalink.Client) -> str | None:
        if self.track:  # cached from an earlier play (loop mode)
            return self.track
        query = f"{self.author} - {self.title}"
        for prefix in ("ytmsearch", "ytsearch"):
            try:
                result = await client.get_tracks(f"{prefix}:{query}")
            except Exception:  # noqa: BLE001 - try the next provider
                continue
            match = pick_best_match(list(result.tracks), self.duration)
            if match is not None and match.track:
                self.track = match.track
                return self.track
        raise lavalink.LoadError(f"Couldn't find a playable version of {self.title}")
