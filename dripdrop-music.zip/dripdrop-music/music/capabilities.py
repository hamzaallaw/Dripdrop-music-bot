"""What the connected Lavalink node can really play.

The bot asks the node (GET /v4/info) which source managers are enabled and refuses
anything else with an honest message, instead of pretending a platform works.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from utils.urls import Platform

# Platforms that can be turned into a YouTube/SoundCloud search once we know the metadata.
_PROVIDERS = ("youtube", "soundcloud")


@dataclass(frozen=True)
class Capabilities:
    source_managers: frozenset[str] = field(default_factory=frozenset)
    plugins: tuple[str, ...] = ()
    version: str = "unknown"

    @classmethod
    def from_info(cls, info: dict[str, Any]) -> Capabilities:
        sources = frozenset(str(s).lower() for s in info.get("sourceManagers", []))
        plugins = tuple(
            f"{p.get('name', '?')} {p.get('version', '')}".strip() for p in info.get("plugins", [])
        )
        version = (info.get("version") or {}).get("semver", "unknown")
        return cls(sources, plugins, str(version))

    @property
    def supports_dave(self) -> bool | None:
        """True if Lavalink is 4.2.0+ (needed for Discord's encrypted voice). None if unknown."""
        parts = self.version.split("-")[0].split(".")
        try:
            major, minor = int(parts[0]), int(parts[1])
        except (ValueError, IndexError):
            return None
        return (major, minor) >= (4, 2)

    @property
    def has_provider(self) -> bool:
        return any(p in self.source_managers for p in _PROVIDERS)

    def status(self, platform: Platform) -> tuple[bool, str]:
        """(playable?, short human note)."""
        if platform is Platform.DEEZER:
            # Metadata comes from Deezer's public API; audio is found on a playable provider.
            if self.has_provider:
                return True, "resolved through YouTube"
            return False, "needs YouTube or SoundCloud enabled to find audio"
        if platform in (Platform.SPOTIFY, Platform.APPLE_MUSIC):
            if platform.source_manager not in self.source_managers:
                return False, "not enabled (needs LavaSrc plus your API keys)"
            if not self.has_provider:
                return False, "needs YouTube or SoundCloud enabled to find audio"
            return True, "resolved through YouTube"
        if platform.source_manager in self.source_managers:
            return True, "native"
        return False, "not enabled on the music server"

    def supports_source(self, manager: str) -> bool:
        return manager in self.source_managers
