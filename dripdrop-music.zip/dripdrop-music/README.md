# DripDrop Music 🎧

A Discord music bot for YouTube, YouTube Music, Spotify, SoundCloud, Apple Music, Deezer, Bandcamp, Twitch, Vimeo, direct audio links and radio streams. Built on Python, discord.py and Lavalink v4.

**Start here: [docs/WINDOWS_GUIDE.md](docs/WINDOWS_GUIDE.md).** Honest list of what is tested: [docs/STATUS.md](docs/STATUS.md).

## Commands
`/play` `/pause` `/resume` `/skip` `/stop` `/previous` `/seek` `/volume` · `/queue` `/clear` `/shuffle` `/remove` `/move` `/loop` `/autoplay` · `/nowplaying` `/lyrics` `/search` `/playlist` (import, save, load, list, delete) `/help` · `/247` `/settings` (admin)

The player message has Play/Pause, Skip, Stop, Loop, Queue, Previous, Shuffle and volume buttons.

## Layout
```
main.py            entry point
bot/               bot setup, error handling, anti-spam
cogs/              slash commands (playback, queue, info, admin) + Lavalink/Discord events
commands/          permission checks, error messages, autocomplete
music/             player, queue, voice, embeds, buttons, source resolving
services/          Deezer metadata, lyrics
database/          SQLite storage
utils/             URL safety, formatting, rate limiting
config/            settings (environment variables) and branding
lavalink/          Lavalink server config (application.yml)
scripts/           test_sources.py: check which platforms work
tests/             160 automated tests
docs/              guides and status
```

## Developing
```
python -m venv .venv && .venv\Scripts\activate   (Windows)   |   source .venv/bin/activate   (Linux/Mac)
pip install -r requirements.txt
python -m pytest
```

## Security
The Discord token and every key live in `.env` (never committed). The bot uses Discord's official bot login only. Links are validated, and anything pointing at local or private addresses is refused. Lavalink only listens on `127.0.0.1`, and the Discord token is not passed to its container. Respect each platform's terms: the bot streams only what Lavalink's sources can legitimately load and does not use Deezer's protected audio.
