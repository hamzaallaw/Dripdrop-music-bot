"""Tests for resolving, capabilities, players, lazy tracks, Deezer and lyrics (no network)."""

from __future__ import annotations

import aiohttp
import lavalink
import pytest
from lavalink import EndReason, LoadResult, LoadResultError, PlaylistInfo, Severity

from music import lazy
from music.capabilities import Capabilities
from music.errors import MusicError, NodeUnavailable, NothingFound, SourceUnavailable
from music.lazy import LazySearchTrack, pick_best_match
from music.service import MusicService, explain_load_error
from music.tracks import deserialize_many, deserialize_track, serialize_track
from services import deezer
from services.lyrics import clean_artist, clean_title, find_lyrics, paginate_text, split_artist_title
from tests.conftest import BASIC_INFO, FULL_INFO, FakeClient, make_track
from utils.urls import Platform


def svc(client, settings):
    return MusicService(client, session=None, settings=settings)  # type: ignore[arg-type]


# ------------------------------------------------------------------ capabilities
def test_capabilities_parse_and_status():
    caps = Capabilities.from_info(FULL_INFO)
    assert caps.version == "4.2.1" and "youtube" in caps.source_managers
    assert caps.status(Platform.YOUTUBE) == (True, "native")
    assert caps.status(Platform.SPOTIFY)[0] is True
    assert caps.status(Platform.DEEZER)[0] is True

    basic = Capabilities.from_info(BASIC_INFO)
    ok, note = basic.status(Platform.SPOTIFY)
    assert not ok and "LavaSrc" in note
    assert basic.status(Platform.DEEZER)[0] is True  # metadata + YouTube mirror works without LavaSrc
    assert basic.status(Platform.BANDCAMP)[0] is True


def test_capabilities_no_provider():
    caps = Capabilities.from_info({"sourceManagers": ["bandcamp", "spotify"]})
    assert not caps.status(Platform.SPOTIFY)[0]
    assert not caps.status(Platform.DEEZER)[0]


@pytest.mark.parametrize(
    "version,expected",
    [("4.2.1", True), ("4.2.0", True), ("4.10.0", True), ("5.0.0", True), ("4.1.2", False),
     ("4.0.8", False), ("4.2.0-beta.1", True), ("unknown", None), ("", None)],
)
def test_dave_version_check(version, expected):
    assert Capabilities(version=version).supports_dave is expected


def test_capabilities_tolerates_garbage():
    caps = Capabilities.from_info({})
    assert caps.source_managers == frozenset() and caps.version == "unknown"


# ------------------------------------------------------------------ resolve
async def test_resolve_search(client, settings):
    client.script["ytsearch:daft punk"] = LoadResult.from_search([make_track("a"), make_track("b")])
    result = await svc(client, settings).resolve("daft punk")
    assert result.kind == "search" and [t.identifier for t in result.tracks] == ["a", "b"]


async def test_resolve_single_track_url(client, settings):
    url = "https://www.youtube.com/watch?v=abc"
    client.script[url] = LoadResult.from_track(make_track("abc"))
    result = await svc(client, settings).resolve(url)
    assert result.kind == "track" and result.platform is Platform.YOUTUBE


async def test_resolve_playlist_truncates(client, settings):
    url = "https://www.youtube.com/playlist?list=PLx"
    tracks = [make_track(f"t{i}") for i in range(10)]
    client.script[url] = LoadResult.from_playlist(tracks, PlaylistInfo("Mix"))
    result = await svc(client, settings).resolve(url)
    assert result.kind == "playlist" and result.title == "Mix"
    assert len(result.tracks) == 3  # MAX_PLAYLIST_IMPORT=3 in test settings
    assert result.extra == {"truncated": True, "total": 10}


async def test_resolve_empty(client, settings):
    with pytest.raises(NothingFound):
        await svc(client, settings).resolve("nothing here")


async def test_resolve_rejects_blank_and_huge(client, settings):
    with pytest.raises(MusicError):
        await svc(client, settings).resolve("   ")
    with pytest.raises(MusicError):
        await svc(client, settings).resolve("x" * 501)


@pytest.mark.parametrize(
    "url",
    ["http://localhost/a.mp3", "http://169.254.169.254/x", "http://10.1.1.1/a.mp3", "ftp://x.com/a", "file:///etc/passwd"],
)
async def test_resolve_blocks_unsafe_urls_before_lavalink(client, settings, url):
    with pytest.raises(MusicError):
        await svc(client, settings).resolve(url)
    assert client.calls == []  # Lavalink never saw it


async def test_resolve_blocks_private_dns(client, settings, monkeypatch):
    async def fake_check(url):
        from utils.urls import UrlCheck

        return UrlCheck(False, "Links to local or private addresses are not allowed.")

    monkeypatch.setattr("music.service.ensure_public_host", fake_check)
    with pytest.raises(MusicError):
        await svc(client, settings).resolve("https://sneaky.example.com/a.mp3")
    assert client.calls == []


async def test_spotify_unavailable_without_lavasrc(settings):
    client = FakeClient(BASIC_INFO)
    with pytest.raises(SourceUnavailable) as exc:
        await svc(client, settings).resolve("https://open.spotify.com/track/123")
    assert "Spotify" in exc.value.message
    assert client.calls == []


async def test_spotify_search_unavailable_without_lavasrc(settings):
    with pytest.raises(SourceUnavailable):
        await svc(FakeClient(BASIC_INFO), settings).resolve("song", source="spotify")


async def test_spotify_works_with_lavasrc(client, settings):
    url = "https://open.spotify.com/track/123"
    client.script[url] = LoadResult.from_track(make_track("sp1", source="spotify"))
    result = await svc(client, settings).resolve(url)
    assert result.platform is Platform.SPOTIFY and result.tracks[0].identifier == "sp1"


async def test_load_error_is_explained(client, settings):
    url = "https://www.youtube.com/watch?v=abc"
    err = LoadResultError.create("Sign in to confirm you're not a bot", Severity.SUSPICIOUS, "x")
    client.script[url] = LoadResult.from_error(err)
    with pytest.raises(MusicError) as exc:
        await svc(client, settings).resolve(url)
    assert "blocking" in exc.value.message


async def test_node_offline(settings):
    with pytest.raises(NodeUnavailable):
        await svc(FakeClient(online=False), settings).resolve("song")


async def test_network_error_becomes_node_unavailable(client, settings):
    client.script["ytsearch:song"] = aiohttp.ClientConnectionError("boom")
    with pytest.raises(NodeUnavailable):
        await svc(client, settings).resolve("song")


def test_explain_load_error_variants():
    assert "age-restricted" in explain_load_error("This video is age restricted")
    assert "private" in explain_load_error("Video is private")
    assert "isn't available" in explain_load_error("Video unavailable")
    assert "couldn't load" in explain_load_error("weird")


async def test_refresh_capabilities_reads_info(client, settings):
    service = svc(client, settings)
    caps = await service.refresh_capabilities()
    assert caps is not None and "spotify" in caps.source_managers


# ------------------------------------------------------------------ deezer
def test_deezer_parse_link():
    assert deezer.parse_link("https://www.deezer.com/track/3135556") == ("track", "3135556")
    assert deezer.parse_link("https://www.deezer.com/en/album/302127") == ("album", "302127")
    assert deezer.parse_link("https://deezer.com/us/playlist/1479458365?utm=x") == ("playlist", "1479458365")
    assert deezer.parse_link("https://deezer.page.link/abc") is None
    assert deezer.parse_link("https://evil.com/track/1") is None
    assert deezer.parse_link("https://www.deezer.com/artist/1") is None


class FakeResponse:
    def __init__(self, data, status=200):
        self._data, self.status = data, status

    async def json(self, content_type=None):
        return self._data

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False


class FakeSession:
    def __init__(self, routes):
        self.routes, self.calls = routes, []

    def get(self, url, params=None, timeout=None):
        self.calls.append((url, params))
        for suffix, resp in self.routes.items():
            if url.endswith(suffix):
                return resp if isinstance(resp, FakeResponse) else FakeResponse(resp)
        return FakeResponse({"error": {"code": 800}})


async def test_deezer_track_and_playlist():
    track_json = {
        "id": 1, "title": "Song", "duration": 200, "link": "https://www.deezer.com/track/1",
        "artist": {"name": "Band"}, "album": {"cover_xl": "https://img/x.jpg"}, "isrc": "US123",
    }
    session = FakeSession(
        {
            "/track/1": track_json,
            "/playlist/9": {"title": "My List", "cover_xl": "https://img/p.jpg"},
            "/playlist/9/tracks": {"data": [track_json, {"id": 2, "title": "Two", "duration": 100, "artist": {"name": "B2"}}, {"bad": 1}]},
        }
    )
    one = await deezer.fetch(session, "https://www.deezer.com/track/1")
    assert one.kind == "track" and one.tracks[0].duration_ms == 200_000 and one.tracks[0].isrc == "US123"
    pl = await deezer.fetch(session, "https://www.deezer.com/playlist/9", limit=50)
    assert pl.name == "My List" and [t.title for t in pl.tracks] == ["Song", "Two"]  # bad item skipped
    assert pl.tracks[1].artwork == "https://img/p.jpg"  # falls back to playlist cover


async def test_deezer_errors():
    with pytest.raises(NothingFound):
        await deezer.fetch(FakeSession({}), "https://www.deezer.com/track/404")
    with pytest.raises(MusicError):
        await deezer.fetch(FakeSession({}), "https://deezer.page.link/short")
    with pytest.raises(MusicError):
        await deezer.fetch(FakeSession({"/track/1": FakeResponse({}, status=500)}), "https://www.deezer.com/track/1")


async def test_resolve_deezer_makes_lazy_tracks(client, settings, monkeypatch):
    async def fake_fetch(session, url, limit):
        return deezer.DeezerResult(
            "album", "Album", [deezer.DeezerTrack("1", "T1", "A", 100_000, "https://www.deezer.com/track/1")]
        )

    monkeypatch.setattr("music.service.deezer.fetch", fake_fetch)
    result = await svc(client, settings).resolve("https://www.deezer.com/album/5", requester=77)
    assert result.kind == "playlist" and isinstance(result.tracks[0], LazySearchTrack)
    assert result.tracks[0].requester == 77 and result.tracks[0].source_name == "deezer"
    assert client.calls == []  # no YouTube searches until play time


async def test_deezer_needs_a_provider(settings):
    client = FakeClient({"sourceManagers": ["bandcamp"]})
    with pytest.raises(SourceUnavailable):
        await svc(client, settings).resolve("https://www.deezer.com/track/1")


# ------------------------------------------------------------------ lazy tracks
def test_pick_best_match_prefers_matching_length():
    a, b, c = make_track("a", duration=400_000), make_track("b", duration=201_000), make_track("c", duration=200_500)
    assert pick_best_match([a, b, c], 200_000).identifier == "c"
    assert pick_best_match([a], 200_000).identifier == "a"  # nothing close: first result
    assert pick_best_match([], 1000) is None
    live = make_track("live", stream=True)
    assert pick_best_match([live, b], 200_000).identifier == "b"


async def test_lazy_track_loads_via_search(client):
    track = LazySearchTrack.create(
        title="Song", author="Artist", duration_ms=200_000, uri="https://x", source_name="deezer", identifier="9"
    )
    client.script["ytmsearch:Artist - Song"] = LoadResult.empty()
    client.script["ytsearch:Artist - Song"] = LoadResult.from_search([make_track("yt1", duration=199_000)])
    encoded = await track.load(client)  # type: ignore[arg-type]
    assert encoded == "enc-yt1" and track.track == "enc-yt1"
    assert client.calls == ["ytmsearch:Artist - Song", "ytsearch:Artist - Song"]
    client.calls.clear()
    assert await track.load(client) == "enc-yt1" and client.calls == []  # cached for loop mode


async def test_lazy_track_fails_cleanly(client):
    track = LazySearchTrack.create(
        title="Nope", author="Nobody", duration_ms=1000, uri="https://x", source_name="deezer", identifier="9"
    )
    with pytest.raises(lavalink.LoadError):
        await track.load(client)  # type: ignore[arg-type]


# ------------------------------------------------------------------ serialization
def test_track_roundtrip():
    original = make_track("abc", title="Hello", requester=42)
    restored = deserialize_track(serialize_track(original))
    assert restored.identifier == "abc" and restored.title == "Hello" and restored.requester == 42
    assert restored.track == original.track


def test_lazy_track_roundtrip():
    lazy_track = LazySearchTrack.create(
        title="L", author="A", duration_ms=5, uri="https://x", source_name="deezer", identifier="1", requester=3
    )
    restored = deserialize_track(serialize_track(lazy_track))
    assert isinstance(restored, LazySearchTrack) and restored.requester == 3


def test_deserialize_survives_damaged_rows():
    good = serialize_track(make_track("ok"))
    items = [good, {"raw": {"info": {}}}, {"nope": 1}, "junk", None, {"raw": None}]
    assert [t.identifier for t in deserialize_many(items)] == ["ok"]


# ------------------------------------------------------------------ player
def test_queue_operations(player):
    for i in range(5):
        player.add(make_track(f"t{i}"), requester=1)
    ids = lambda: [t.identifier for t in player.queue]  # noqa: E731
    assert player.move(5, 1).identifier == "t4" and ids() == ["t4", "t0", "t1", "t2", "t3"]
    assert player.remove(2).identifier == "t0" and ids() == ["t4", "t1", "t2", "t3"]
    before = set(ids())
    player.shuffle_queue()
    assert set(ids()) == before and len(player.queue) == 4
    assert player.clear() == 4 and player.queue == []
    for bad in (0, 1, -1):
        with pytest.raises(IndexError):
            player.remove(bad)
    with pytest.raises(IndexError):
        player.move(1, 9)


def test_total_queue_ms_ignores_streams(player):
    player.add(make_track("a", duration=1000))
    player.add(make_track("b", duration=2000))
    player.add(make_track("radio", stream=True, duration=0))
    assert player.total_queue_ms() == 3000


def test_history_rules(player):
    a, b, c = make_track("a"), make_track("b"), make_track("c")
    player.record_finished(a, EndReason.FINISHED)
    player.record_finished(b, EndReason.REPLACED)  # skipped
    player.record_finished(c, EndReason.STOPPED)  # /stop: not remembered
    player.record_finished(None, EndReason.FINISHED)
    player.record_finished(make_track("lf"), EndReason.LOAD_FAILED)
    assert [t.identifier for t in player.history] == ["a", "b"]


def test_history_not_duplicated_when_looping_one(player):
    player.loop = player.LOOP_SINGLE
    player.record_finished(make_track("a"), EndReason.FINISHED)
    assert player.history == []


def test_history_is_capped(player):
    for i in range(80):
        player.record_finished(make_track(f"t{i}"), EndReason.FINISHED)
    assert len(player.history) == 50 and player.history[-1].identifier == "t79"


async def test_previous_goes_back_without_duplicating(player):
    played = []

    async def fake_play(track=None, **kw):
        played.append(track.identifier)
        player.current = track

    player.play = fake_play  # type: ignore[method-assign]
    a, b = make_track("a"), make_track("b")
    player.history = [a]
    player.current = b
    player.queue = [make_track("c")]

    prev = await player.play_previous()
    assert prev.identifier == "a" and played == ["a"]
    assert [t.identifier for t in player.queue] == ["b", "c"]  # b waits right after a
    # The REPLACED event for b must NOT push b back onto history.
    player.record_finished(b, EndReason.REPLACED)
    assert player.history == []
    assert await player.play_previous() is None


async def test_previous_with_empty_history(player):
    assert await player.play_previous() is None


async def test_skip_while_looping_one_moves_on(player):
    seen = {}

    async def fake_skip():
        seen["loop_during_skip"] = player.loop

    player.skip = fake_skip  # type: ignore[method-assign]
    player.loop = player.LOOP_SINGLE
    await player.skip_track()
    assert seen["loop_during_skip"] == player.LOOP_NONE and player.loop == player.LOOP_SINGLE
    player.loop = player.LOOP_QUEUE
    await player.skip_track()
    assert seen["loop_during_skip"] == player.LOOP_QUEUE


def test_snapshot_restore_roundtrip(player, client):
    from types import SimpleNamespace

    from music.player import MusicPlayer

    player.current = make_track("now", duration=300_000)
    player.channel_id = 5
    player._last_position = 90_000
    player._last_update = 10**18  # freeze the position clock far in the future is not needed; just snapshot
    player.queue = [make_track("q1", requester=9), make_track("q2")]
    player.loop = player.LOOP_QUEUE
    state = player.snapshot()

    other = MusicPlayer(2, SimpleNamespace(manager=SimpleNamespace(client=client), name="fake"))
    resume, position = other.restore(state)
    assert resume.identifier == "now" and isinstance(position, int)
    assert [t.identifier for t in other.queue] == ["q1", "q2"] and other.queue[0].requester == 9
    assert other.loop == other.LOOP_QUEUE


def test_restore_rejects_bad_state(player):
    assert player.restore({"v": 99}) == (None, 0)
    assert player.restore("garbage") == (None, 0)  # type: ignore[arg-type]
    resume, pos = player.restore({"v": 1, "queue": ["x"], "loop": 7, "current": None})
    assert resume is None and pos == 0 and player.queue == [] and player.loop == 0


def test_restore_ignores_position_for_streams(player):
    state = {"v": 1, "queue": [], "loop": 0, "position": 5000, "current": serialize_track(make_track("r", stream=True))}
    resume, pos = player.restore(state)
    assert resume.is_stream and pos == 0


# ------------------------------------------------------------------ autoplay
async def test_autoplay_uses_youtube_mix_and_skips_recent(client, settings, player):
    seed = make_track("seed")
    player._last_started = seed
    player.recent_ids.extend(["played1"])
    mix = f"https://www.youtube.com/watch?v=seed&list=RDseed"
    client.script[mix] = LoadResult.from_playlist(
        [make_track("seed"), make_track("played1"), make_track("fresh")], PlaylistInfo("Mix")
    )
    pick = await svc(client, settings).autoplay_next(player)
    assert pick.identifier == "fresh"


async def test_autoplay_falls_back_to_artist_search(client, settings, player):
    player._last_started = make_track("sp", source="spotify", author="Cool Band - Topic")
    client.script["ytmsearch:Cool Band"] = LoadResult.from_search([make_track("r1")])
    pick = await svc(client, settings).autoplay_next(player)
    assert pick.identifier == "r1"


async def test_autoplay_nothing_for_streams_or_no_history(client, settings, player):
    service = svc(client, settings)
    assert await service.autoplay_next(player) is None
    player._last_started = make_track("radio", stream=True)
    assert await service.autoplay_next(player) is None


async def test_autoplay_survives_node_failure(client, settings, player):
    player._last_started = make_track("seed")
    client.script["https://www.youtube.com/watch?v=seed&list=RDseed"] = aiohttp.ClientConnectionError("x")
    assert await svc(client, settings).autoplay_next(player) is None


# ------------------------------------------------------------------ lyrics
@pytest.mark.parametrize(
    "raw,expected",
    [
        ("Song Name (Official Video)", "Song Name"),
        ("Song Name [Official Lyric Video] (HD)", "Song Name"),
        ("Song Name (feat. Someone Else)", "Song Name"),
        ("Song (Live at Wembley)", "Song"),
        ("Plain Title", "Plain Title"),
        ("Song (Remix by DJ X)", "Song (Remix by DJ X)"),  # real part of the title is kept
    ],
)
def test_clean_title(raw, expected):
    assert clean_title(raw) == expected


def test_artist_title_splitting():
    assert split_artist_title("Daft Punk - One More Time (Official Video)", "DaftPunkVEVO") == ("Daft Punk", "One More Time")
    assert split_artist_title("One More Time", "Daft Punk - Topic") == ("Daft Punk", "One More Time")
    assert clean_artist("ArtistVEVO") == "Artist"


def test_paginate_text():
    assert paginate_text("") == [""]
    text = "\n".join(f"line {i}" for i in range(1000))
    pages = paginate_text(text, limit=500)
    assert all(len(p) <= 500 for p in pages) and len(pages) > 1
    assert "\n".join(pages).replace("\n", "") == text.replace("\n", "")  # nothing lost
    assert all(len(p) <= 50 for p in paginate_text("x" * 120, limit=50))


async def test_find_lyrics_exact_then_search():
    item = {"trackName": "Song", "artistName": "Band", "plainLyrics": "la la la", "instrumental": False}
    exact = FakeSession({"/get": item})
    found = await find_lyrics(exact, "Band - Song (Official Video)", "chan", 200_000)
    assert found.text == "la la la" and exact.calls[0][1]["duration"] == 200

    fallback = FakeSession({"/get": FakeResponse({}, status=404), "/search": [{"plainLyrics": ""}, item]})
    assert (await find_lyrics(fallback, "Song", "Band")).artist == "Band"

    assert await find_lyrics(FakeSession({"/get": FakeResponse({}, 404), "/search": []}), "x", "y") is None


async def test_find_lyrics_instrumental_and_network_failure():
    inst = FakeSession({"/get": {"trackName": "I", "artistName": "A", "plainLyrics": None, "instrumental": True}})
    assert (await find_lyrics(inst, "I", "A")).instrumental is True

    class Boom:
        def get(self, *a, **k):
            raise aiohttp.ClientConnectionError("down")

    assert await find_lyrics(Boom(), "x", "y") is None
