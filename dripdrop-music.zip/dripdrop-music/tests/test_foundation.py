"""Tests for settings, formatting, URL safety, anti-spam and the database."""

from __future__ import annotations

import pytest

from config.settings import ConfigError, load_settings
from database.db import Database
from utils.formatting import format_duration, parse_timestamp, progress_bar, truncate
from utils.ratelimit import SpamGuard
from utils.urls import (
    Platform,
    build_identifier,
    detect_platform,
    ensure_public_host,
    is_url,
    validate_url,
)

TOKEN = "x" * 60


# ---------------------------------------------------------------- settings
def env(**overrides: str) -> dict[str, str]:
    base = {"DISCORD_TOKEN": TOKEN, "LAVALINK_PASSWORD": "pw"}
    base.update(overrides)
    return base


def test_settings_defaults():
    s = load_settings(environ=env())
    assert s.lavalink_port == 2333 and s.default_volume == 60 and s.dev_guild_id is None
    assert "token" in repr(s) and TOKEN not in repr(s)


@pytest.mark.parametrize(
    "bad",
    [
        {"DISCORD_TOKEN": ""},
        {"DISCORD_TOKEN": "short"},
        {"LAVALINK_PASSWORD": ""},
        {"LAVALINK_PORT": "abc"},
        {"LAVALINK_PORT": "70000"},
        {"LOG_LEVEL": "LOUD"},
        {"LAVALINK_SSL": "maybe"},
        {"OWNER_IDS": "1,two"},
        {"DEFAULT_VOLUME": "9999"},
    ],
)
def test_settings_rejects_bad_values(bad):
    with pytest.raises(ConfigError):
        load_settings(environ=env(**bad))


def test_settings_owner_ids_and_dev_guild():
    s = load_settings(environ=env(OWNER_IDS="1, 2,3", DEV_GUILD_ID="42"))
    assert s.owner_ids == {1, 2, 3} and s.dev_guild_id == 42


# ---------------------------------------------------------------- formatting
@pytest.mark.parametrize(
    "ms,expected",
    [(0, "0:00"), (12_345, "0:12"), (61_000, "1:01"), (3_725_000, "1:02:05"), (-5, "0:00")],
)
def test_format_duration(ms, expected):
    assert format_duration(ms) == expected


def test_format_duration_stream():
    assert format_duration(0, is_stream=True) == "LIVE"


def test_progress_bar_positions():
    assert progress_bar(0, 100, length=10).startswith("🔘")
    assert progress_bar(100, 100, length=10).endswith("🔘")
    assert progress_bar(50, 100, length=10).count("🔘") == 1
    assert "LIVE" in progress_bar(5, 0)
    assert "LIVE" in progress_bar(5, 100, is_stream=True)


@pytest.mark.parametrize(
    "text,expected",
    [
        ("90", 90_000), ("1:30", 90_000), ("1:02:03", 3_723_000),
        ("1m30s", 90_000), ("2h", 7_200_000), ("45s", 45_000),
        ("1:75", None), ("abc", None), ("", None), ("-5", None),
    ],
)
def test_parse_timestamp(text, expected):
    assert parse_timestamp(text) == expected


def test_truncate():
    assert truncate("hello", 10) == "hello"
    assert truncate("hello world", 6) == "hello…"


# ---------------------------------------------------------------- urls
@pytest.mark.parametrize(
    "url,platform",
    [
        ("https://www.youtube.com/watch?v=abc", Platform.YOUTUBE),
        ("https://youtu.be/abc", Platform.YOUTUBE),
        ("https://music.youtube.com/watch?v=abc", Platform.YOUTUBE_MUSIC),
        ("https://open.spotify.com/track/123", Platform.SPOTIFY),
        ("https://soundcloud.com/a/b", Platform.SOUNDCLOUD),
        ("https://music.apple.com/us/album/x/1", Platform.APPLE_MUSIC),
        ("https://www.deezer.com/track/1", Platform.DEEZER),
        ("https://artist.bandcamp.com/track/x", Platform.BANDCAMP),
        ("https://www.twitch.tv/somechannel", Platform.TWITCH),
        ("https://vimeo.com/76979871", Platform.VIMEO),
        ("https://example.com/song.mp3", Platform.HTTP),
        ("https://ice1.somafm.com/groovesalad-128-mp3", Platform.HTTP),
        ("https://notyoutube.com/x", Platform.HTTP),
        ("https://evilyoutube.com.attacker.net/x", Platform.HTTP),
    ],
)
def test_detect_platform(url, platform):
    assert detect_platform(url) is platform


@pytest.mark.parametrize(
    "url",
    [
        "http://localhost/x.mp3", "http://127.0.0.1/x", "http://192.168.1.5/x", "http://10.0.0.1/x",
        "http://169.254.169.254/latest/meta-data", "http://[::1]/x", "http://printer.local/x",
        "ftp://example.com/x", "file:///etc/passwd", "javascript:alert(1)",
        "https://user:pass@example.com/x", "https://", "https://exa mple.com/x",
        "https://example.com:99999/x", "https://" + "a" * 2100 + ".com",
    ],
)
def test_validate_url_rejects(url):
    assert not validate_url(url).ok


@pytest.mark.parametrize(
    "url", ["https://www.youtube.com/watch?v=abc", "http://example.com/a.mp3", "https://8.8.8.8/x"]
)
def test_validate_url_accepts(url):
    assert validate_url(url).ok


def test_is_url_and_identifier():
    assert is_url("https://a.b/c") and not is_url("daft punk")
    assert build_identifier("daft punk") == "ytsearch:daft punk"
    assert build_identifier("daft punk", "youtube_music") == "ytmsearch:daft punk"
    assert build_identifier("daft punk", "soundcloud") == "scsearch:daft punk"
    assert build_identifier("daft punk", "spotify") == "spsearch:daft punk"
    assert build_identifier("daft punk", "apple_music") == "amsearch:daft punk"
    assert build_identifier("daft punk", "bogus") == "ytsearch:daft punk"
    assert build_identifier(" https://x.y/z ") == "https://x.y/z"


async def test_ensure_public_host_blocks_localhost_name(monkeypatch):
    import asyncio
    import socket

    async def fake_getaddrinfo(self, host, port, **kw):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 0))]

    monkeypatch.setattr(asyncio.get_running_loop().__class__, "getaddrinfo", fake_getaddrinfo)
    assert not (await ensure_public_host("https://sneaky.example.com/x.mp3")).ok


async def test_ensure_public_host_allows_public(monkeypatch):
    import asyncio
    import socket

    async def fake_getaddrinfo(self, host, port, **kw):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 0))]

    monkeypatch.setattr(asyncio.get_running_loop().__class__, "getaddrinfo", fake_getaddrinfo)
    assert (await ensure_public_host("https://example.com/x.mp3")).ok


# ---------------------------------------------------------------- anti-spam
def test_spam_guard_blocks_then_recovers():
    now = [0.0]
    guard = SpamGuard(rate=3, per=10, clock=lambda: now[0])
    assert [guard.check(1) for _ in range(3)] == [0.0, 0.0, 0.0]
    wait = guard.check(1)
    assert 0 < wait <= 10
    assert guard.check(2) == 0.0  # other users are independent
    now[0] = 10.5
    assert guard.check(1) == 0.0


def test_spam_guard_validates_args():
    with pytest.raises(ValueError):
        SpamGuard(rate=0)


# ---------------------------------------------------------------- database
@pytest.fixture
async def db():
    database = Database(":memory:")
    await database.connect()
    yield database
    await database.close()


async def test_db_settings_roundtrip(db):
    s = await db.get_settings(1, default_volume=55)
    assert s["volume"] == 55 and s["always_on"] == 0
    await db.update_settings(1, volume=80, always_on=1, voice_channel_id=99)
    s = await db.get_settings(1)
    assert (s["volume"], s["always_on"], s["voice_channel_id"]) == (80, 1, 99)
    assert [g["guild_id"] for g in await db.always_on_guilds()] == [1]


async def test_db_rejects_unknown_setting(db):
    with pytest.raises(ValueError):
        await db.update_settings(1, evil="1; DROP TABLE guild_settings")


async def test_db_queue_persistence(db):
    assert await db.load_queue(5) is None
    await db.save_queue(5, {"queue": [{"a": 1}], "loop": 2})
    await db.save_queue(5, {"queue": [], "loop": 0})  # upsert
    assert await db.load_queue(5) == {"queue": [], "loop": 0}
    await db.clear_queue_state(5)
    assert await db.load_queue(5) is None


async def test_db_playlists(db):
    tracks = [{"encoded": "abc"}]
    assert await db.save_playlist(7, "Chill", tracks) == "created"
    assert await db.save_playlist(7, "chill", tracks + tracks) == "updated"  # case-insensitive
    assert await db.list_playlists(7) == [{"name": "Chill", "tracks": 2}]
    assert len(await db.get_playlist(7, "CHILL")) == 2
    assert await db.get_playlist(8, "Chill") is None  # other users cannot read it
    assert await db.delete_playlist(7, "chill") is True
    assert await db.delete_playlist(7, "chill") is False


async def test_db_playlist_limits(db):
    with pytest.raises(ValueError):
        await db.save_playlist(1, "", [{"a": 1}])
    with pytest.raises(ValueError):
        await db.save_playlist(1, "x", [])
    for i in range(25):
        await db.save_playlist(1, f"p{i}", [{"a": i}])
    with pytest.raises(ValueError):
        await db.save_playlist(1, "one-too-many", [{"a": 1}])


async def test_db_sql_injection_in_playlist_name(db):
    name = "x'; DROP TABLE playlists; --"
    await db.save_playlist(1, name, [{"a": 1}])
    assert await db.get_playlist(1, name) == [{"a": 1}]
