"""Checks that the bot assembles: every cog loads, every slash command is a valid Discord
definition, and embeds and views build. No Discord or Lavalink connection is made."""

from __future__ import annotations

from types import SimpleNamespace

import discord
import lavalink
import pytest

from bot.client import EXTENSIONS, DripDropBot
from commands.checks import is_dj
from commands.errors import describe_error
from config.settings import load_settings
from music import embeds
from music.capabilities import Capabilities
from music.errors import MusicError
from music.player import MusicPlayer
from music.views import LyricsView, PlayerView, QueueView
from services.lyrics import Lyrics
from tests.conftest import FULL_INFO, make_track

REQUIRED = {
    "play", "pause", "resume", "skip", "stop", "previous", "seek", "volume",
    "queue", "clear", "shuffle", "remove", "move", "loop", "autoplay",
    "nowplaying", "lyrics", "search", "playlist", "help", "247", "settings",
}


@pytest.fixture
async def bot(tmp_path, monkeypatch):
    # The watchdog loops need a logged-in bot. Wiring tests never log in, so don't start them.
    # (discord.py re-imports extensions as fresh modules, so patch the loop starter itself.)
    from discord.ext import tasks

    monkeypatch.setattr(tasks.Loop, "start", lambda self, *a, **k: None)
    settings = load_settings(
        environ={"DISCORD_TOKEN": "x" * 60, "LAVALINK_PASSWORD": "pw", "DATABASE_PATH": str(tmp_path / "t.db")}
    )
    b = DripDropBot(settings)
    await b.db.connect()
    b.lavalink = lavalink.Client(123456789, player=MusicPlayer)
    from music.service import MusicService

    b.music = MusicService(b.lavalink, None, settings)  # type: ignore[arg-type]
    for ext in EXTENSIONS:
        await b.load_extension(ext)
    yield b
    await b.lavalink.close()
    await b.db.close()


async def test_all_cogs_load_and_every_requested_command_exists(bot):
    names = {c.name for c in bot.tree.get_commands()}
    assert REQUIRED <= names, f"missing: {REQUIRED - names}"


async def test_slash_command_payloads_are_valid_for_discord(bot):
    import re

    pattern = re.compile(r"^[-_\w]{1,32}$")
    for command in bot.tree.get_commands():
        payload = command.to_dict(bot.tree)
        assert pattern.match(payload["name"]) and payload["name"] == payload["name"].lower()
        assert 1 <= len(payload["description"]) <= 100, command.name
        for option in payload.get("options", []):
            assert pattern.match(option["name"]), (command.name, option["name"])
            assert 1 <= len(option["description"]) <= 100, (command.name, option["name"])
            for choice in option.get("choices", []):
                assert len(str(choice["name"])) <= 100
    assert len(bot.tree.get_commands()) <= 100


async def test_admin_commands_require_manage_server(bot):
    by_name = {c.name: c.to_dict(bot.tree) for c in bot.tree.get_commands()}
    manage_guild = discord.Permissions(manage_guild=True).value
    assert int(by_name["247"]["default_member_permissions"]) == manage_guild
    assert int(by_name["settings"]["default_member_permissions"]) == manage_guild


async def test_no_prefix_command_is_offered(bot):
    assert "prefix" not in {c.name for c in bot.tree.get_commands()}


def make_player(bot):
    node = SimpleNamespace(manager=SimpleNamespace(client=bot.lavalink), name="n")
    return MusicPlayer(1, node)


async def test_now_playing_embed(bot):
    player = make_player(bot)
    track = make_track("a", title="**bold** @everyone title", author="Band", duration=200_000)
    track.requester = 42
    player.current = track
    player.queue = [make_track("b")]
    embed = embeds.now_playing(player, bot_id=1)
    assert "@everyone" not in embed.title.replace("@​everyone", "")  # mentions are defanged
    assert "<@42>" in [f.value for f in embed.fields if f.name == "Requested by"][0]
    assert any("Volume" in f.name for f in embed.fields)
    assert "3:20" in embed.description and "🔘" in embed.description
    assert embed.footer.text.endswith("1 up next")


async def test_now_playing_autoplay_and_stream(bot):
    player = make_player(bot)
    stream = make_track("radio", stream=True, duration=0)
    stream.requester = 1  # the bot id means autoplay picked it
    player.current = stream
    embed = embeds.now_playing(player, bot_id=1)
    assert "Autoplay" in [f.value for f in embed.fields if f.name == "Requested by"][0]
    assert "LIVE" in embed.description


async def test_idle_embed_when_nothing_playing(bot):
    assert "Nothing is playing" in embeds.now_playing(make_player(bot), 1).description


async def test_queue_pagination_embed(bot):
    player = make_player(bot)
    player.queue = [make_track(f"t{i}", title=f"Song {i}") for i in range(25)]
    assert embeds.queue_pages(player, 1) == 3
    page3 = embeds.queue_page(player, 1, 3)
    assert "Page 3/3" in page3.footer.text and "`25.`" in page3.description and "`10.`" not in page3.description
    assert "Page 3/3" in embeds.queue_page(player, 1, 99).footer.text  # clamped
    assert "empty" in embeds.queue_page(make_player(bot), 1).description


async def test_long_titles_never_exceed_discord_limits(bot):
    player = make_player(bot)
    player.current = make_track("a", title="T" * 900, author="A" * 900)
    player.queue = [make_track(f"q{i}", title="Q" * 500, author="Z" * 500) for i in range(10)]
    now = embeds.now_playing(player, 1)
    assert len(now.title) <= 256 and len(now.description) <= 4096
    q = embeds.queue_page(player, 1)
    assert len(q.description) <= 4096 and len(q) <= 6000
    res = embeds.search_results("x" * 500, [make_track(f"s{i}", title="S" * 500) for i in range(10)])
    assert len(res.title) <= 256 and len(res.description) <= 4096


async def test_help_embed_is_honest_about_platforms(bot):
    full = embeds.help_embed(Capabilities.from_info(FULL_INFO), True)
    text = "\n".join(f.value for f in full.fields)
    assert "Spotify" in text and "Bandcamp" in text
    basic = embeds.help_embed(Capabilities.from_info({"sourceManagers": ["youtube", "http"]}), True)
    platforms = [f.value for f in basic.fields if f.name.startswith("Platforms")][0]
    assert "❌ Spotify" in platforms and "✅ YouTube" in platforms
    offline = embeds.help_embed(None, False)
    assert "offline" in [f.value for f in offline.fields if f.name.startswith("Platforms")][0]
    assert all(len(f.value) <= 1024 for f in full.fields) and len(full) <= 6000


async def test_player_view_has_required_buttons_with_stable_ids(bot):
    view = PlayerView(bot)
    ids = {c.custom_id for c in view.children}
    assert {"dd:playpause", "dd:skip", "dd:stop", "dd:loop", "dd:queue"} <= ids
    assert view.timeout is None and len(view.children) <= 25
    assert all(len(c.custom_id) <= 100 for c in view.children)


async def test_player_view_reflects_state(bot):
    player = make_player(bot)
    player.paused = True
    player.loop = player.LOOP_SINGLE
    view = PlayerView(bot, player)
    assert str(view.play_pause.emoji) == "▶️"
    assert str(view.loop.emoji) == "🔂" and view.loop.style is discord.ButtonStyle.success


async def test_lyrics_and_queue_views(bot):
    long = Lyrics("T", "A", "\n".join(f"line {i}" for i in range(1500)))
    view = LyricsView(long, owner_id=5)
    assert len(view.pages) > 1 and len(view.render().description) <= 4096
    short = LyricsView(Lyrics("T", "A", "hi"), owner_id=5)
    assert short.children == []  # no page buttons needed
    assert QueueView(bot, 1, 5).owner_id == 5


async def test_dj_permission_rules():
    def member(*, admin=False, manage=False, roles=()):
        perms = discord.Permissions(administrator=admin, manage_guild=manage)
        return SimpleNamespace(
            id=7, guild_permissions=perms, roles=[SimpleNamespace(id=r) for r in roles]
        )

    assert is_dj(member(), None)  # no DJ role set: everyone
    assert not is_dj(member(), 99)
    assert is_dj(member(roles=[99]), 99)
    assert is_dj(member(manage=True), 99) and is_dj(member(admin=True), 99)
    alone = SimpleNamespace(members=[SimpleNamespace(id=7, bot=False), SimpleNamespace(id=8, bot=True)])
    assert is_dj(member(), 99, alone)  # sole listener controls their own session
    crowd = SimpleNamespace(members=[SimpleNamespace(id=7, bot=False), SimpleNamespace(id=9, bot=False)])
    assert not is_dj(member(), 99, crowd)


async def test_error_messages_are_friendly():
    assert describe_error(MusicError("Nope")) == ("Nope", False)
    from discord import app_commands

    wrapped = app_commands.CommandInvokeError(SimpleNamespace(name="x", qualified_name="x"), MusicError("Inner"))  # type: ignore[arg-type]
    assert describe_error(wrapped) == ("Inner", False)
    message, unexpected = describe_error(ValueError("secret stack detail"))
    assert unexpected and "secret" not in message
    bug = app_commands.CommandInvokeError(SimpleNamespace(name="x", qualified_name="x"), KeyError("k"))  # type: ignore[arg-type]
    assert describe_error(bug)[1] is True
