"""Runs the REAL Lavalink.py client against a small fake Lavalink v4 server.

This proves our connection, capability detection, track loading and reconnect handling work with
Lavalink's wire protocol. It does NOT prove audio plays: that needs a real Lavalink (see
scripts/test_sources.py).
"""

from __future__ import annotations

import asyncio

import lavalink
import pytest
from aiohttp import WSMsgType, web

from config.settings import load_settings
from music.errors import MusicError, SourceUnavailable
from music.player import MusicPlayer
from music.service import MusicService
from tests.conftest import FULL_INFO

PASSWORD = "secret"


def track_json(identifier: str, title: str = "Song", length: int = 180_000) -> dict:
    return {
        "encoded": f"enc-{identifier}",
        "info": {
            "identifier": identifier, "isSeekable": True, "author": "Artist", "length": length,
            "isStream": False, "position": 0, "title": title, "uri": f"https://example.com/{identifier}",
            "artworkUrl": None, "isrc": None, "sourceName": "youtube",
        },
        "pluginInfo": {},
        "userData": {},
    }


class FakeLavalink:
    def __init__(self, info=None):
        self.info = info if info is not None else FULL_INFO
        self.loads: list[str] = []
        self.sockets: list[web.WebSocketResponse] = []
        self.runner: web.AppRunner | None = None
        self.port = 0

    def _authorized(self, request: web.Request) -> bool:
        return request.headers.get("Authorization") == PASSWORD

    async def ws(self, request: web.Request) -> web.StreamResponse:
        if not self._authorized(request):
            return web.Response(status=401)
        sock = web.WebSocketResponse()
        await sock.prepare(request)
        self.sockets.append(sock)
        await sock.send_json({"op": "ready", "resumed": False, "sessionId": "sess-1"})
        async for msg in sock:
            if msg.type == WSMsgType.ERROR:
                break
        return sock

    async def get_info(self, request: web.Request) -> web.Response:
        if not self._authorized(request):
            return web.Response(status=401)
        return web.json_response(self.info)

    async def load(self, request: web.Request) -> web.Response:
        if not self._authorized(request):
            return web.Response(status=401)
        ident = request.query["identifier"]
        self.loads.append(ident)
        if ident == "ytsearch:daft punk":
            return web.json_response({"loadType": "search", "data": [track_json("a", "One More Time"), track_json("b")]})
        if ident == "https://www.youtube.com/watch?v=abc":
            return web.json_response({"loadType": "track", "data": track_json("abc")})
        if ident == "https://www.youtube.com/playlist?list=PL1":
            return web.json_response(
                {"loadType": "playlist", "data": {"info": {"name": "Mix", "selectedTrack": -1}, "pluginInfo": {}, "tracks": [track_json("p1"), track_json("p2")]}}
            )
        if ident == "https://www.youtube.com/watch?v=blocked":
            return web.json_response(
                {"loadType": "error", "data": {"message": "Sign in to confirm you're not a bot", "severity": "suspicious", "cause": "x"}}
            )
        return web.json_response({"loadType": "empty", "data": {}})

    async def start(self, port: int = 0) -> None:
        app = web.Application()
        app.router.add_get("/v4/websocket", self.ws)
        app.router.add_get("/v4/info", self.get_info)
        app.router.add_get("/v4/loadtracks", self.load)
        self.runner = web.AppRunner(app)
        await self.runner.setup()
        site = web.TCPSite(self.runner, "127.0.0.1", port)
        await site.start()
        self.port = site._server.sockets[0].getsockname()[1]  # type: ignore[union-attr]

    async def stop(self) -> None:
        for sock in self.sockets:
            await sock.close()
        if self.runner:
            await self.runner.cleanup()


async def wait_for(predicate, timeout=5.0):
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        if predicate():
            return True
        await asyncio.sleep(0.05)
    return predicate()


@pytest.fixture
async def stack():
    fake = FakeLavalink()
    await fake.start()
    client = lavalink.Client(111, player=MusicPlayer)
    client.add_node("127.0.0.1", fake.port, PASSWORD, "eu", name="main")
    settings = load_settings(environ={"DISCORD_TOKEN": "x" * 60, "LAVALINK_PASSWORD": PASSWORD})
    service = MusicService(client, None, settings)  # type: ignore[arg-type]
    assert await wait_for(lambda: service.online), "client never connected to the fake Lavalink"
    yield fake, client, service
    await client.close()
    await fake.stop()


async def test_connects_and_reads_capabilities(stack):
    fake, client, service = stack
    caps = await service.refresh_capabilities()
    assert caps is not None and caps.version == "4.2.1"
    assert {"youtube", "soundcloud", "spotify"} <= caps.source_managers
    assert any("youtube-plugin" in p for p in caps.plugins)


async def test_search_track_and_playlist_through_real_client(stack):
    fake, client, service = stack
    search = await service.resolve("daft punk")
    assert search.kind == "search" and search.tracks[0].title == "One More Time"
    one = await service.resolve("https://www.youtube.com/watch?v=abc")
    assert one.kind == "track" and one.tracks[0].identifier == "abc"
    pl = await service.resolve("https://www.youtube.com/playlist?list=PL1")
    assert pl.kind == "playlist" and pl.title == "Mix" and len(pl.tracks) == 2


async def test_lavalink_error_reaches_user_as_friendly_message(stack):
    _, _, service = stack
    with pytest.raises(MusicError) as exc:
        await service.resolve("https://www.youtube.com/watch?v=blocked")
    assert "blocking" in exc.value.message


async def test_unsupported_platform_never_reaches_lavalink():
    fake = FakeLavalink(info={"version": {"semver": "4.2.1"}, "sourceManagers": ["youtube", "http"], "plugins": []})
    await fake.start()
    client = lavalink.Client(111, player=MusicPlayer)
    client.add_node("127.0.0.1", fake.port, PASSWORD, "eu", name="main")
    settings = load_settings(environ={"DISCORD_TOKEN": "x" * 60, "LAVALINK_PASSWORD": PASSWORD})
    service = MusicService(client, None, settings)  # type: ignore[arg-type]
    try:
        assert await wait_for(lambda: service.online)
        with pytest.raises(SourceUnavailable):
            await service.resolve("https://open.spotify.com/track/123")
        with pytest.raises(SourceUnavailable):
            await service.resolve("https://soundcloud.com/a/b")
        assert fake.loads == []
    finally:
        await client.close()
        await fake.stop()


async def test_wrong_password_is_not_online():
    fake = FakeLavalink()
    await fake.start()
    client = lavalink.Client(111, player=MusicPlayer)
    client.add_node("127.0.0.1", fake.port, "WRONG", "eu", name="main")
    settings = load_settings(environ={"DISCORD_TOKEN": "x" * 60, "LAVALINK_PASSWORD": "x"})
    service = MusicService(client, None, settings)  # type: ignore[arg-type]
    try:
        await asyncio.sleep(1.0)
        assert not service.online
        with pytest.raises(MusicError) as exc:
            await service.resolve("daft punk")
        assert "offline" in exc.value.message
    finally:
        await client.close()
        await fake.stop()


async def test_detects_outage_and_recovers(stack):
    fake, client, service = stack
    events: list[str] = []

    class Hooks:
        @lavalink.listener(lavalink.NodeDisconnectedEvent)
        async def down(self, event):
            events.append("down")

        @lavalink.listener(lavalink.NodeReadyEvent)
        async def ready(self, event):
            events.append("ready")

    client.add_event_hooks(Hooks())
    for sock in list(fake.sockets):  # simulate Lavalink dropping the connection
        await sock.close()
    assert await wait_for(lambda: "down" in events, 8), events
    assert await wait_for(lambda: service.online and events.count("ready") >= 1, 15), events
    result = await service.resolve("daft punk")  # works again after reconnect
    assert result.kind == "search"
