"""Shared fakes: a scripted Lavalink client and helpers to build tracks and players."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest
from lavalink import AudioTrack, LoadResult

from config.settings import load_settings
from music.player import MusicPlayer


def make_track(
    identifier: str = "vid1",
    title: str = "Song",
    author: str = "Artist",
    duration: int = 200_000,
    source: str = "youtube",
    stream: bool = False,
    requester: int = 0,
) -> AudioTrack:
    return AudioTrack(
        {
            "encoded": f"enc-{identifier}",
            "info": {
                "identifier": identifier,
                "isSeekable": not stream,
                "author": author,
                "length": duration,
                "isStream": stream,
                "position": 0,
                "title": title,
                "uri": f"https://example.com/{identifier}",
                "artworkUrl": None,
                "isrc": None,
                "sourceName": source,
            },
            "pluginInfo": {},
        },
        requester,
    )


class FakeNode:
    def __init__(self, info: dict[str, Any] | None = None):
        self.name = "fake"
        self._info = info if info is not None else {}

    async def get_info(self) -> dict[str, Any]:
        return self._info


class FakeClient:
    """Stands in for lavalink.Client. `script` maps identifier -> LoadResult or an Exception."""

    def __init__(self, info: dict[str, Any] | None = None, online: bool = True):
        self.node = FakeNode(info)
        self.node_manager = SimpleNamespace(available_nodes=[self.node] if online else [])
        self.script: dict[str, Any] = {}
        self.calls: list[str] = []

    async def get_tracks(self, query: str, node: Any = None, check_local: bool = False) -> LoadResult:
        self.calls.append(query)
        outcome = self.script.get(query, LoadResult.empty())
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


FULL_INFO = {
    "version": {"semver": "4.2.1"},
    "sourceManagers": [
        "youtube", "soundcloud", "bandcamp", "twitch", "vimeo", "http", "spotify", "applemusic",
    ],
    "plugins": [{"name": "youtube-plugin", "version": "1.18.2"}, {"name": "lavasrc-plugin", "version": "4.8.3"}],
}
BASIC_INFO = {
    "version": {"semver": "4.2.1"},
    "sourceManagers": ["youtube", "soundcloud", "bandcamp", "twitch", "vimeo", "http"],
    "plugins": [{"name": "youtube-plugin", "version": "1.18.2"}],
}


@pytest.fixture
def settings():
    return load_settings(
        environ={"DISCORD_TOKEN": "x" * 60, "LAVALINK_PASSWORD": "pw", "MAX_PLAYLIST_IMPORT": "3"}
    )


@pytest.fixture
def client():
    return FakeClient(FULL_INFO)


@pytest.fixture
def player(client):
    node = SimpleNamespace(manager=SimpleNamespace(client=client), name="fake")
    return MusicPlayer(1, node)
