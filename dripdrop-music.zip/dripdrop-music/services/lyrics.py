"""Lyrics lookup through LRCLIB (https://lrclib.net), a free community lyrics API.

The bot only fetches lyrics when a user asks. Nothing is stored. LRCLIB asks clients to send
a descriptive User-Agent, which the bot's shared HTTP session does.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

import aiohttp

API = "https://lrclib.net/api"

_NOISE = re.compile(
    r"[\(\[\{][^\)\]\}]*(official|video|audio|lyrics?|lyric video|visuali[sz]er|hd|hq|4k|remaster(?:ed)?|"
    r"live|explicit|clean|mv|m/v|music video)[^\)\]\}]*[\)\]\}]",
    re.IGNORECASE,
)
_FEAT = re.compile(r"\s*[\(\[]?\s*\b(?:feat\.?|ft\.?|featuring)\s+[^\)\]]*[\)\]]?", re.IGNORECASE)
_CHANNEL_SUFFIX = re.compile(r"\s*(?:-\s*topic|vevo|official)$", re.IGNORECASE)


@dataclass(frozen=True)
class Lyrics:
    title: str
    artist: str
    text: str
    instrumental: bool = False


def clean_title(title: str) -> str:
    title = _NOISE.sub("", title)
    title = _FEAT.sub("", title)
    return re.sub(r"\s{2,}", " ", title).strip(" -–|")


def clean_artist(artist: str) -> str:
    return _CHANNEL_SUFFIX.sub("", artist).strip()


def split_artist_title(title: str, author: str) -> tuple[str, str]:
    """YouTube titles are often 'Artist - Song'. Prefer that over the channel name."""
    cleaned = clean_title(title)
    for sep in (" - ", " – ", " — "):
        if sep in cleaned:
            left, right = cleaned.split(sep, 1)
            if left.strip() and right.strip():
                return left.strip(), right.strip()
    return clean_artist(author), cleaned


def paginate_text(text: str, limit: int = 3500) -> list[str]:
    """Split on line breaks so no page is longer than `limit` characters."""
    pages: list[str] = []
    current = ""
    for line in text.replace("\r\n", "\n").split("\n"):
        while len(line) > limit:  # a single enormous line
            if current:
                pages.append(current.rstrip())
                current = ""
            pages.append(line[:limit])
            line = line[limit:]
        if len(current) + len(line) + 1 > limit:
            pages.append(current.rstrip())
            current = ""
        current += line + "\n"
    if current.strip():
        pages.append(current.rstrip())
    return pages or [""]


def _from_item(item: dict[str, Any]) -> Lyrics | None:
    if not isinstance(item, dict):
        return None
    text = item.get("plainLyrics") or ""
    instrumental = bool(item.get("instrumental"))
    if not text and not instrumental:
        return None
    return Lyrics(
        title=str(item.get("trackName") or ""),
        artist=str(item.get("artistName") or ""),
        text=str(text),
        instrumental=instrumental,
    )


async def _request(session: aiohttp.ClientSession, path: str, params: dict[str, Any]) -> Any:
    try:
        async with session.get(
            f"{API}{path}", params=params, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status == 404:
                return None
            if resp.status != 200:
                return None
            return await resp.json(content_type=None)
    except (aiohttp.ClientError, TimeoutError):
        return None


async def find_lyrics(
    session: aiohttp.ClientSession,
    title: str,
    author: str = "",
    duration_ms: int = 0,
) -> Lyrics | None:
    """Exact match first, then a looser search. None when nothing is found."""
    artist, song = split_artist_title(title, author)
    params: dict[str, Any] = {"track_name": song, "artist_name": artist}
    if duration_ms > 0:
        params["duration"] = round(duration_ms / 1000)
    found = _from_item(await _request(session, "/get", params) or {})
    if found:
        return found

    results = await _request(session, "/search", {"q": f"{artist} {song}".strip()})
    if isinstance(results, list):
        for item in results[:5]:
            found = _from_item(item)
            if found:
                return found
    return None
