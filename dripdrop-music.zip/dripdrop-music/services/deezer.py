"""Deezer metadata through Deezer's public API (no key needed).

We only read titles, artists and lengths. Audio is never taken from Deezer: the bot finds
the same song on a playable provider (see music.lazy).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

import aiohttp

from music.errors import MusicError, NothingFound

API = "https://api.deezer.com"
_LINK_RE = re.compile(
    r"^https?://(?:www\.)?deezer\.com/(?:[a-z]{2}(?:-[a-z]{2})?/)?(track|album|playlist)/(\d{1,15})(?:[/?#].*)?$",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class DeezerTrack:
    id: str
    title: str
    artist: str
    duration_ms: int
    url: str
    artwork: str | None = None
    isrc: str | None = None


@dataclass
class DeezerResult:
    kind: str  # "track" | "album" | "playlist"
    name: str
    tracks: list[DeezerTrack] = field(default_factory=list)


def parse_link(url: str) -> tuple[str, str] | None:
    """Return (kind, id) for a Deezer track/album/playlist link, else None."""
    match = _LINK_RE.match(url.strip())
    if not match:
        return None
    return match.group(1).lower(), match.group(2)


def _track(item: dict[str, Any], fallback_art: str | None = None) -> DeezerTrack | None:
    try:
        title = str(item["title"])
        artist = str((item.get("artist") or {}).get("name") or "Unknown artist")
        duration = int(item.get("duration") or 0) * 1000
        album = item.get("album") or {}
        art = album.get("cover_xl") or album.get("cover_big") or fallback_art
        return DeezerTrack(
            id=str(item["id"]),
            title=title,
            artist=artist,
            duration_ms=duration,
            url=str(item.get("link") or f"https://www.deezer.com/track/{item['id']}"),
            artwork=art,
            isrc=item.get("isrc"),
        )
    except (KeyError, TypeError, ValueError):
        return None


async def _get(session: aiohttp.ClientSession, path: str, **params: Any) -> dict[str, Any]:
    try:
        async with session.get(
            f"{API}{path}", params=params or None, timeout=aiohttp.ClientTimeout(total=10)
        ) as resp:
            if resp.status != 200:
                raise MusicError("Deezer didn't answer. Try again in a moment.")
            data = await resp.json(content_type=None)
    except (aiohttp.ClientError, TimeoutError) as exc:
        raise MusicError("I couldn't reach Deezer right now.") from exc
    if not isinstance(data, dict):
        raise MusicError("Deezer sent an unexpected answer.")
    if "error" in data:
        raise NothingFound("Deezer says that link doesn't exist or isn't public.")
    return data


async def fetch(session: aiohttp.ClientSession, url: str, limit: int = 100) -> DeezerResult:
    parsed = parse_link(url)
    if parsed is None:
        raise MusicError(
            "That Deezer link isn't supported. Use a deezer.com track, album or playlist link "
            "(short deezer.page.link links can't be opened)."
        )
    kind, item_id = parsed
    limit = max(1, min(limit, 100))

    if kind == "track":
        data = await _get(session, f"/track/{item_id}")
        track = _track(data)
        if track is None:
            raise NothingFound("I couldn't read that Deezer track.")
        return DeezerResult("track", track.title, [track])

    meta = await _get(session, f"/{kind}/{item_id}")
    listing = await _get(session, f"/{kind}/{item_id}/tracks", limit=limit)
    cover = meta.get("cover_xl") or meta.get("cover_big")
    tracks = [t for item in listing.get("data", []) if (t := _track(item, cover))]
    if not tracks:
        raise NothingFound("That Deezer link has no playable tracks.")
    return DeezerResult(kind, str(meta.get("title") or kind.title()), tracks[:limit])
