"""One place that turns any slash-command failure into a friendly message."""

from __future__ import annotations

import logging

import discord
from discord import app_commands

from music import embeds
from music.errors import MusicError

log = logging.getLogger(__name__)


def describe_error(error: Exception) -> tuple[str, bool]:
    """Return (message for the user, whether it is an unexpected bug)."""
    if isinstance(error, app_commands.CommandInvokeError) and error.original is not error:
        inner = error.original
        if isinstance(inner, MusicError):
            return inner.message, False
        error = inner  # type: ignore[assignment]
    if isinstance(error, MusicError):
        return error.message, False
    if isinstance(error, app_commands.NoPrivateMessage):
        return "This only works inside a server.", False
    if isinstance(error, app_commands.MissingPermissions):
        return "You need the Manage Server permission to do that.", False
    if isinstance(error, app_commands.BotMissingPermissions):
        names = ", ".join(p.replace("_", " ").title() for p in error.missing_permissions)
        return f"I'm missing permissions: {names}.", False
    if isinstance(error, app_commands.CommandOnCooldown):
        return f"Slow down! Try again in {error.retry_after:.0f}s.", False
    if isinstance(error, app_commands.CheckFailure):
        return "You can't use that command here.", False
    return "Something went wrong on my side. Please try again.", True


async def handle_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
    message, unexpected = describe_error(error)
    if unexpected:
        name = interaction.command.qualified_name if interaction.command else "unknown"
        log.error("Unhandled error in /%s", name, exc_info=error)
    await send_error(interaction, message)


async def send_error(interaction: discord.Interaction, message: str) -> None:
    embed = embeds.error(message)
    try:
        if interaction.response.is_done():
            await interaction.followup.send(embed=embed, ephemeral=True)
        else:
            await interaction.response.send_message(embed=embed, ephemeral=True)
    except discord.HTTPException:
        log.debug("Could not deliver an error message (interaction expired)")
