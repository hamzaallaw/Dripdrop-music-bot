"""Autocomplete helpers. They only read the local queue, so they never hit YouTube."""

from __future__ import annotations

import discord
from discord import app_commands

from music.voice import get_player
from utils.formatting import clean, truncate


async def queue_position(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[int]]:
    if interaction.guild is None:
        return []
    player = get_player(interaction.client, interaction.guild.id)
    if player is None or not player.queue:
        return []
    needle = current.strip().lower()
    out: list[app_commands.Choice[int]] = []
    for index, track in enumerate(player.queue, start=1):
        label = f"{index}. {truncate(clean(track.title), 80)}"
        if not needle or needle in label.lower():
            out.append(app_commands.Choice(name=label, value=index))
        if len(out) == 25:
            break
    return out
