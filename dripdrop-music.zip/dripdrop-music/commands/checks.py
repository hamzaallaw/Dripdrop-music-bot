"""Permission and voice-channel checks shared by slash commands and player buttons."""

from __future__ import annotations

from typing import TYPE_CHECKING

import discord

from music.errors import MusicError
from music.player import MusicPlayer
from music.voice import get_player

if TYPE_CHECKING:
    from bot.client import DripDropBot

VoiceLike = discord.VoiceChannel | discord.StageChannel


def user_voice_channel(interaction: discord.Interaction) -> VoiceLike | None:
    user = interaction.user
    voice = getattr(user, "voice", None)
    return voice.channel if voice and voice.channel else None


def require_voice(interaction: discord.Interaction) -> VoiceLike:
    channel = user_voice_channel(interaction)
    if channel is None:
        raise MusicError("Join a voice channel first, then try again.")
    return channel


def humans_in(channel: VoiceLike) -> list[discord.Member]:
    return [m for m in channel.members if not m.bot]


def is_dj(member: discord.Member, dj_role_id: int | None, channel: VoiceLike | None = None) -> bool:
    perms = member.guild_permissions
    if perms.administrator or perms.manage_guild:
        return True
    if not dj_role_id:
        return True
    if any(role.id == dj_role_id for role in member.roles):
        return True
    # The only listener is always in charge of their own session.
    return channel is not None and [m.id for m in humans_in(channel)] == [member.id]


async def control_player(
    bot: DripDropBot,
    interaction: discord.Interaction,
    *,
    dj: bool = True,
    need_track: bool = False,
) -> MusicPlayer:
    """Return the guild's player after checking the user may control it.

    Raises MusicError (shown to the user) when they may not.
    """
    if interaction.guild is None or not isinstance(interaction.user, discord.Member):
        raise MusicError("This only works inside a server.")
    player = get_player(bot, interaction.guild.id)
    if player is None or not player.is_connected:
        raise MusicError("I'm not playing anything right now. Start with `/play`.")
    if need_track and player.current is None:
        raise MusicError("Nothing is playing right now.")

    channel = interaction.guild.get_channel(player.channel_id) if player.channel_id else None
    if user_voice_channel(interaction) != channel:
        where = channel.mention if channel else "my voice channel"
        raise MusicError(f"Join {where} to control the music.")
    if dj:
        settings = await bot.db.get_settings(interaction.guild.id, default_volume=bot.settings.default_volume)
        if not is_dj(interaction.user, settings.get("dj_role_id"), channel):  # type: ignore[arg-type]
            raise MusicError("Only members with the DJ role (or Manage Server) can do that.")
    return player
